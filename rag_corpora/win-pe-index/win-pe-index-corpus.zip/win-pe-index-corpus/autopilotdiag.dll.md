---
name: autopilotdiag.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# autopilotdiag.dll

**Description:** ETW for Autopilot Diagnostics
**Type:** dll
**Path:** C:\Windows\System32\autopilotdiag.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
