---
name: bthserv.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.3037 (WinBuild.160101.0800)
---
# bthserv.dll

**Description:** Bluetooth Support Service
**Type:** dll
**Path:** C:\Windows\System32\bthserv.dll
**Version:** 10.0.26100.3037 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
