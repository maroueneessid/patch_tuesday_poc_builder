---
name: certca.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# certca.dll

**Description:** Microsoft® Active Directory Certificate Services CA
**Type:** dll
**Path:** C:\Windows\System32\certca.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
