---
name: amdave64.dll
source: pe-index
type: dll
location: system32
version: 18.4.6.0
---
# amdave64.dll

**Description:** Radeon AMD AVE Driver Component
**Type:** dll
**Path:** C:\Windows\System32\amdave64.dll
**Version:** 18.4.6.0
**Product:** Advanced Micro Devices, Inc. Radeon AMD AVE Driver Component
