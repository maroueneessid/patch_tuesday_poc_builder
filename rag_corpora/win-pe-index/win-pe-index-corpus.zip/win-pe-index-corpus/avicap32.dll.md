---
name: avicap32.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# avicap32.dll

**Description:** AVI Capture window class
**Type:** dll
**Path:** C:\Windows\System32\avicap32.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
