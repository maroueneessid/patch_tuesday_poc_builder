---
name: audiosrv.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.5074 (WinBuild.160101.0800)
---
# audiosrv.dll

**Description:** Windows Audio Service
**Type:** dll
**Path:** C:\Windows\System32\audiosrv.dll
**Version:** 10.0.26100.5074 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
