---
name: AccountHealth.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.3912 (WinBuild.160101.0800)
---
# AccountHealth.dll

**Description:** AccountHealth
**Type:** dll
**Path:** C:\Windows\System32\AccountHealth.dll
**Version:** 10.0.26100.3912 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
