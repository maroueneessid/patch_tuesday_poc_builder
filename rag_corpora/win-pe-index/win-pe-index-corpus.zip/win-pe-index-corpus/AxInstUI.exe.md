---
name: AxInstUI.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# AxInstUI.exe

**Description:** ActiveX Installer Service
**Type:** exe
**Path:** C:\Windows\System32\AxInstUI.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
