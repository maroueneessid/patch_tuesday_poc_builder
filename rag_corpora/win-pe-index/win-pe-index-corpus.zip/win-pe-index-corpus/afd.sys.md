---
name: afd.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.8036 (WinBuild.160101.0800)
---
# afd.sys

**Description:** Ancillary Function Driver for WinSock
**Type:** driver
**Path:** C:\Windows\System32\drivers\afd.sys
**Version:** 10.0.26100.8036 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
