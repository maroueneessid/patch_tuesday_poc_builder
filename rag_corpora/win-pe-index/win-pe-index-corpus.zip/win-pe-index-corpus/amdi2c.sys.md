---
name: amdi2c.sys
source: pe-index
type: driver
location: drivers
version: 1.2.0.126
---
# amdi2c.sys

**Description:** AMD I2C Controller Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\amdi2c.sys
**Version:** 1.2.0.126
**Product:** AMD I2C Controller Driver
