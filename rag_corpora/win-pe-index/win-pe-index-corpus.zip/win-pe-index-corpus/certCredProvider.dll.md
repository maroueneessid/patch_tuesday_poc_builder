---
name: certCredProvider.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.4484 (WinBuild.160101.0800)
---
# certCredProvider.dll

**Description:** Cert Credential Provider
**Type:** dll
**Path:** C:\Windows\System32\certCredProvider.dll
**Version:** 10.0.26100.4484 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
