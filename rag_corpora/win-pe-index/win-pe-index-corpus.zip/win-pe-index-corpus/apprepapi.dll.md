---
name: apprepapi.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.4484 (WinBuild.160101.0800)
---
# apprepapi.dll

**Description:** Application Reputation APIs Dll
**Type:** dll
**Path:** C:\Windows\System32\apprepapi.dll
**Version:** 10.0.26100.4484 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
