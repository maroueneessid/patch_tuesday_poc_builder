---
name: amdsata.sys
source: pe-index
type: driver
location: drivers
version: 1.1.3.277 (NT.150223-1854)
---
# amdsata.sys

**Description:** AHCI 1.3 Device Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\amdsata.sys
**Version:** 1.1.3.277 (NT.150223-1854)
**Product:** AHCI 1.3 Device Driver
