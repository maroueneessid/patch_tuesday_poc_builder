---
name: atiadlxx.dll
source: pe-index
type: dll
location: system32
version: 7.25.10.1590
---
# atiadlxx.dll

**Description:** ADL
**Type:** dll
**Path:** C:\Windows\System32\atiadlxx.dll
**Version:** 7.25.10.1590
**Product:** ADL Component
