---
name: AcLayers.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7705 (WinBuild.160101.0800)
---
# AcLayers.dll

**Description:** Windows Compatibility DLL
**Type:** dll
**Path:** C:\Windows\System32\AcLayers.dll
**Version:** 10.0.26100.7705 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
