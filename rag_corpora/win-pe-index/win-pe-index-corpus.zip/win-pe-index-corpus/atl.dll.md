---
name: atl.dll
source: pe-index
type: dll
location: system32
version: 3.05.2284
---
# atl.dll

**Description:** ATL Module for Windows XP (Unicode)
**Type:** dll
**Path:** C:\Windows\System32\atl.dll
**Version:** 3.05.2284
**Product:** Microsoft (R) Visual C++
