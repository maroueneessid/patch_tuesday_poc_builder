---
name: cht4vx64.sys
source: pe-index
type: driver
location: drivers
version: 6.11.4.100
---
# cht4vx64.sys

**Description:** Virtual Bus Driver for Chelsio ® T5/T6 Chipset
**Type:** driver
**Path:** C:\Windows\System32\drivers\cht4vx64.sys
**Version:** 6.11.4.100
**Product:** Chelsio Communications Unified Network I/O Controller
