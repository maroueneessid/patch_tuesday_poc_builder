---
name: circlass.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# circlass.sys

**Description:** Consumer IR Class Driver for eHome
**Type:** driver
**Path:** C:\Windows\System32\drivers\circlass.sys
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
