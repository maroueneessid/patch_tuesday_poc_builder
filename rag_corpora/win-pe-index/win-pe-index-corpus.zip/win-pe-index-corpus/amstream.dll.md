---
name: amstream.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.5074 (WinBuild.160101.0800)
---
# amstream.dll

**Description:** DirectShow Runtime.
**Type:** dll
**Path:** C:\Windows\System32\amstream.dll
**Version:** 10.0.26100.5074 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
