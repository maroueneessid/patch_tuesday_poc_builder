---
name: AuthBroker.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# AuthBroker.dll

**Description:** Web Authentication WinRT API
**Type:** dll
**Path:** C:\Windows\System32\AuthBroker.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
