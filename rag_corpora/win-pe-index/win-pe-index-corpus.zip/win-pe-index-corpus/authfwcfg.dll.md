---
name: authfwcfg.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# authfwcfg.dll

**Description:** Windows Defender Firewall with Advanced Security Configuration Helper
**Type:** dll
**Path:** C:\Windows\System32\authfwcfg.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
