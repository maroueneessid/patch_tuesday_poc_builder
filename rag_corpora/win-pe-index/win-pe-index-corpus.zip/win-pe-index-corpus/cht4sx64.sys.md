---
name: cht4sx64.sys
source: pe-index
type: driver
location: drivers
version: 6.11.4.100
---
# cht4sx64.sys

**Description:** Chelsio iSCSI VMiniport Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\cht4sx64.sys
**Version:** 6.11.4.100
**Product:** Chelsio Communications iSCSI Controller
