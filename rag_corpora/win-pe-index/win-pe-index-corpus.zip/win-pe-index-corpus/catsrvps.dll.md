---
name: catsrvps.dll
source: pe-index
type: dll
location: system32
version: 2001.12.10941.16384 (WinBuild.160101.0800)
---
# catsrvps.dll

**Description:** COM+ Configuration Catalog Server Proxy/Stub
**Type:** dll
**Path:** C:\Windows\System32\catsrvps.dll
**Version:** 2001.12.10941.16384 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
