---
name: cacls.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# cacls.exe

**Description:** Control ACLs Program
**Type:** exe
**Path:** C:\Windows\System32\cacls.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
