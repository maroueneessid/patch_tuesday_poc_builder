---
name: ClipSVC.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7922 (WinBuild.160101.0800)
---
# ClipSVC.dll

**Description:** Client License Service
**Type:** dll
**Path:** C:\Windows\System32\ClipSVC.dll
**Version:** 10.0.26100.7922 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
