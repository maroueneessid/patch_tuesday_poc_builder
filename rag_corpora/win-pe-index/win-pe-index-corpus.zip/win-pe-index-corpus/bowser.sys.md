---
name: bowser.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# bowser.sys

**Description:** NT Lan Manager Datagram Receiver Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\bowser.sys
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
