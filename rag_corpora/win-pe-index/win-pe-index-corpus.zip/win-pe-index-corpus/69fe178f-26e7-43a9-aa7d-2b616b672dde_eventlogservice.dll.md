---
name: 69fe178f-26e7-43a9-aa7d-2b616b672dde_eventlogservice.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7705 (WinBuild.160101.0800)
---
# 69fe178f-26e7-43a9-aa7d-2b616b672dde_eventlogservice.dll

**Description:** ApiSet Schema Extension DLL
**Type:** dll
**Path:** C:\Windows\System32\69fe178f-26e7-43a9-aa7d-2b616b672dde_eventlogservice.dll
**Version:** 10.0.26100.7705 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
