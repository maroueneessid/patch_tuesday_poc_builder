---
name: cmgrcspps.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.4202 (WinBuild.160101.0800)
---
# cmgrcspps.dll

**Description:** cmgrcspps
**Type:** dll
**Path:** C:\Windows\System32\cmgrcspps.dll
**Version:** 10.0.26100.4202 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
