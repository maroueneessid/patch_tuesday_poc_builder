---
name: bcastdvr.proxy.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# bcastdvr.proxy.dll

**Description:** Broadcast DVR Proxy
**Type:** dll
**Path:** C:\Windows\System32\bcastdvr.proxy.dll
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
