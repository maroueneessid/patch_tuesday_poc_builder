---
name: amd_comgr.dll
source: pe-index
type: dll
location: system32
version: 
---
# amd_comgr.dll

**Description:** No description available
**Type:** dll
**Path:** C:\Windows\System32\amd_comgr.dll
**Version:** 
**Product:** 
