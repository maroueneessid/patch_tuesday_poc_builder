---
name: CIDiag.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.5074 (WinBuild.160101.0800)
---
# CIDiag.exe

**Description:** CodeIntegrity Diagnostic Tool
**Type:** exe
**Path:** C:\Windows\System32\CIDiag.exe
**Version:** 10.0.26100.5074 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
