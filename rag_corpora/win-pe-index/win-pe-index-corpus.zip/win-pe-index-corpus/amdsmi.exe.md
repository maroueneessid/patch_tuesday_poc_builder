---
name: amdsmi.exe
source: pe-index
type: exe
location: system32
version: 
---
# amdsmi.exe

**Description:** No description available
**Type:** exe
**Path:** C:\Windows\System32\amdsmi.exe
**Version:** 
**Product:** 
