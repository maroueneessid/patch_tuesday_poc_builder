---
name: CallButtons.ProxyStub.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.4202 (WinBuild.160101.0800)
---
# CallButtons.ProxyStub.dll

**Description:** Windows Runtime CallButtonsServer ProxyStub DLL
**Type:** dll
**Path:** C:\Windows\System32\CallButtons.ProxyStub.dll
**Version:** 10.0.26100.4202 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
