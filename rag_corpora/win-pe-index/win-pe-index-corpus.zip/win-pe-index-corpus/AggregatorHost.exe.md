---
name: AggregatorHost.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.7824 (WinBuild.160101.0800)
---
# AggregatorHost.exe

**Description:** Microsoft (R) Aggregator Host
**Type:** exe
**Path:** C:\Windows\System32\AggregatorHost.exe
**Version:** 10.0.26100.7824 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
