---
name: amdgpio2.sys
source: pe-index
type: driver
location: drivers
version: 2.2.0.134
---
# amdgpio2.sys

**Description:** AMD GPIO Controller Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\amdgpio2.sys
**Version:** 2.2.0.134
**Product:** AMD GPIO Controller Driver
