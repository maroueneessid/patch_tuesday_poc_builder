---
name: cmstplua.dll
source: pe-index
type: dll
location: system32
version: 7.2.26100.1 (WinBuild.160101.0800)
---
# cmstplua.dll

**Description:** Connection Manager Admin API Helper for Setup
**Type:** dll
**Path:** C:\Windows\System32\cmstplua.dll
**Version:** 7.2.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft(R) Connection Manager
