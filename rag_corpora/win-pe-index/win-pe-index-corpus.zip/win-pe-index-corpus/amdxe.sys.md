---
name: amdxe.sys
source: pe-index
type: driver
location: drivers
version: 25.10.0.1
---
# amdxe.sys

**Description:** AMD Controller Emulation
**Type:** driver
**Path:** C:\Windows\System32\drivers\amdxe.sys
**Version:** 25.10.0.1
**Product:** AMD Driver
