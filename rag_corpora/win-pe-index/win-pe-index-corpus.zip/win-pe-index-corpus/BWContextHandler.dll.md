---
name: BWContextHandler.dll
source: pe-index
type: dll
location: system32
version: 1, 0, 0, 1
---
# BWContextHandler.dll

**Description:** ContextH Application
**Type:** dll
**Path:** C:\Windows\System32\BWContextHandler.dll
**Version:** 1, 0, 0, 1
**Product:** ContextH Application
