---
name: AppListBackupLauncher.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7824 (WinBuild.160101.0800)
---
# AppListBackupLauncher.dll

**Description:** AppListBackupLauncher
**Type:** dll
**Path:** C:\Windows\System32\AppListBackupLauncher.dll
**Version:** 10.0.26100.7824 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
