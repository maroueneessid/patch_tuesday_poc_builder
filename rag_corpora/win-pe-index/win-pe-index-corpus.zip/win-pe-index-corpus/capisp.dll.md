---
name: capisp.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# capisp.dll

**Description:** Sysprep cleanup dll for CAPI
**Type:** dll
**Path:** C:\Windows\System32\capisp.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
