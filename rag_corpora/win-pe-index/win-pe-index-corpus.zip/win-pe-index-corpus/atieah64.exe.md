---
name: atieah64.exe
source: pe-index
type: exe
location: system32
version: 
---
# atieah64.exe

**Description:** No description available
**Type:** exe
**Path:** C:\Windows\System32\atieah64.exe
**Version:** 
**Product:** 
