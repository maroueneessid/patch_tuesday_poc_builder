---
name: atimuixx.dll
source: pe-index
type: dll
location: system32
version: 6, 14, 10, 1002
---
# atimuixx.dll

**Description:** Multi-language DPPE DLL
**Type:** dll
**Path:** C:\Windows\System32\atimuixx.dll
**Version:** 6, 14, 10, 1002
**Product:** Multi-language DPPE DLL
