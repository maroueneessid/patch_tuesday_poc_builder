---
name: aticfx64.dll
source: pe-index
type: dll
location: system32
version: 8.17.10.1700
---
# aticfx64.dll

**Description:** aticfxstub64.dll
**Type:** dll
**Path:** C:\Windows\System32\aticfx64.dll
**Version:** 8.17.10.1700
**Product:** AMD Inc. Radeon DirectX 11 Driver
