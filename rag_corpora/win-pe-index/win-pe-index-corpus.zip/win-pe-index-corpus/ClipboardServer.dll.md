---
name: ClipboardServer.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# ClipboardServer.dll

**Description:** Modern Clipboard API Server
**Type:** dll
**Path:** C:\Windows\System32\ClipboardServer.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
