---
name: appsruprov.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# appsruprov.dll

**Description:** Application System Resource Usage Monitor (SRUM) provider
**Type:** dll
**Path:** C:\Windows\System32\appsruprov.dll
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
