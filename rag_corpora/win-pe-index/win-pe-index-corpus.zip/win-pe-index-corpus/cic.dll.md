---
name: cic.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.3915 (WinBuild.160101.0800)
---
# cic.dll

**Description:** CIC - MMC controls for Taskpad
**Type:** dll
**Path:** C:\Windows\System32\cic.dll
**Version:** 10.0.26100.3915 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
