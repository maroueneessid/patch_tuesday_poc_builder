---
name: adhapi.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7705 (WinBuild.160101.0800)
---
# adhapi.dll

**Description:** AD harvest sites and subnets API
**Type:** dll
**Path:** C:\Windows\System32\adhapi.dll
**Version:** 10.0.26100.7705 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
