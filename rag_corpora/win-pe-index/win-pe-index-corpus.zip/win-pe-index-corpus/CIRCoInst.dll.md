---
name: CIRCoInst.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# CIRCoInst.dll

**Description:** USB Consumer IR Driver coinstaller for eHome
**Type:** dll
**Path:** C:\Windows\System32\CIRCoInst.dll
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
