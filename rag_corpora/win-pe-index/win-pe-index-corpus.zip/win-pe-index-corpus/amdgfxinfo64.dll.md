---
name: amdgfxinfo64.dll
source: pe-index
type: dll
location: system32
version: 
---
# amdgfxinfo64.dll

**Description:** No description available
**Type:** dll
**Path:** C:\Windows\System32\amdgfxinfo64.dll
**Version:** 
**Product:** 
