---
name: BluetoothApis.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# BluetoothApis.dll

**Description:** Bluetooth Usermode Api host
**Type:** dll
**Path:** C:\Windows\System32\BluetoothApis.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
