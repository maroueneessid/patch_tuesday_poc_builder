---
name: aehd.sys
source: pe-index
type: driver
location: drivers
version: 2.2
---
# aehd.sys

**Description:** Android Emulator hypervisor driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\aehd.sys
**Version:** 2.2
**Product:** Android Emulator hypervisor driver
