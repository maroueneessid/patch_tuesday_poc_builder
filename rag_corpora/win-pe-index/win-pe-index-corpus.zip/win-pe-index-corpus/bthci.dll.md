---
name: bthci.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# bthci.dll

**Description:** Bluetooth Class Installer
**Type:** dll
**Path:** C:\Windows\System32\bthci.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
