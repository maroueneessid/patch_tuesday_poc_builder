---
name: CloudExperienceHostUser.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# CloudExperienceHostUser.dll

**Description:** CloudExperienceHost User Operations
**Type:** dll
**Path:** C:\Windows\System32\CloudExperienceHostUser.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
