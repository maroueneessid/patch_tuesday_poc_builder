---
name: cca.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1882 (WinBuild.160101.0800)
---
# cca.dll

**Description:** CCA DirectShow Filter.
**Type:** dll
**Path:** C:\Windows\System32\cca.dll
**Version:** 10.0.26100.1882 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
