---
name: clinfo.exe
source: pe-index
type: exe
location: system32
version: 
---
# clinfo.exe

**Description:** No description available
**Type:** exe
**Path:** C:\Windows\System32\clinfo.exe
**Version:** 
**Product:** 
