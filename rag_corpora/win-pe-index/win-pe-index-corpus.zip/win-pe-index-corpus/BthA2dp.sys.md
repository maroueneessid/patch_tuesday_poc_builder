---
name: BthA2dp.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# BthA2dp.sys

**Description:** Bluetooth A2DP Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\BthA2dp.sys
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
