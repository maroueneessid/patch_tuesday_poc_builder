---
name: autofstx.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.2454 (WinBuild.160101.0800)
---
# autofstx.exe

**Description:** FsTx Auto Recovery Utility
**Type:** exe
**Path:** C:\Windows\System32\autofstx.exe
**Version:** 10.0.26100.2454 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
