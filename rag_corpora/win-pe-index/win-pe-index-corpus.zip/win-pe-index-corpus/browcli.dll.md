---
name: browcli.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# browcli.dll

**Description:** Browser Service Client DLL
**Type:** dll
**Path:** C:\Windows\System32\browcli.dll
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
