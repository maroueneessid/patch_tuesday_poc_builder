---
name: cfgmgr32.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# cfgmgr32.dll

**Description:** Configuration Manager DLL
**Type:** dll
**Path:** C:\Windows\System32\cfgmgr32.dll
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
