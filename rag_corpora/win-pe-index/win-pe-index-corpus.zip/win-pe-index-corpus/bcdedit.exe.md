---
name: bcdedit.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# bcdedit.exe

**Description:** Boot Configuration Data Editor
**Type:** exe
**Path:** C:\Windows\System32\bcdedit.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
