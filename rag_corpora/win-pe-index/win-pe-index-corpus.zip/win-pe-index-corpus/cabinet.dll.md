---
name: cabinet.dll
source: pe-index
type: dll
location: system32
version: 5.00 (WinBuild.160101.0800)
---
# cabinet.dll

**Description:** Microsoft® Cabinet File API
**Type:** dll
**Path:** C:\Windows\System32\cabinet.dll
**Version:** 5.00 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
