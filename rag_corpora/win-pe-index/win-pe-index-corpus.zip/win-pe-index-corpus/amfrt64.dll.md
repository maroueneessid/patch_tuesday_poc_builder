---
name: amfrt64.dll
source: pe-index
type: dll
location: system32
version: 
---
# amfrt64.dll

**Description:** No description available
**Type:** dll
**Path:** C:\Windows\System32\amfrt64.dll
**Version:** 
**Product:** 
