---
name: BitLockerWizardElev.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.6725 (WinBuild.160101.0800)
---
# BitLockerWizardElev.exe

**Description:** BitLocker Drive Encryption Wizard
**Type:** exe
**Path:** C:\Windows\System32\BitLockerWizardElev.exe
**Version:** 10.0.26100.6725 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
