---
name: amsiproxy.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# amsiproxy.dll

**Description:** Anti-Malware Scan Interface proxy
**Type:** dll
**Path:** C:\Windows\System32\amsiproxy.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
