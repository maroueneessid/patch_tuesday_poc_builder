---
name: ClipUp.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# ClipUp.exe

**Description:** Client License Platform migration tool
**Type:** exe
**Path:** C:\Windows\System32\ClipUp.exe
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
