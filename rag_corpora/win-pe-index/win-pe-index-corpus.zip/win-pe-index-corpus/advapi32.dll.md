---
name: advapi32.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.3624 (WinBuild.160101.0800)
---
# advapi32.dll

**Description:** Advanced Windows 32 Base API
**Type:** dll
**Path:** C:\Windows\System32\advapi32.dll
**Version:** 10.0.26100.3624 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
