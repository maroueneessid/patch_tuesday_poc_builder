---
name: AtBroker.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.8036 (WinBuild.160101.0800)
---
# AtBroker.exe

**Description:** Windows Assistive Technology Manager
**Type:** exe
**Path:** C:\Windows\System32\AtBroker.exe
**Version:** 10.0.26100.8036 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
