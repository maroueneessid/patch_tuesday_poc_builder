---
name: clip.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# clip.exe

**Description:** Clip - copies the data into clipboard
**Type:** exe
**Path:** C:\Windows\System32\clip.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
