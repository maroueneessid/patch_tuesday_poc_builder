---
name: CastSrv.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.7019 (WinBuild.160101.0800)
---
# CastSrv.exe

**Description:** Casting protocol connection listener
**Type:** exe
**Path:** C:\Windows\System32\CastSrv.exe
**Version:** 10.0.26100.7019 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
