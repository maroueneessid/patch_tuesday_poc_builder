---
name: bcdsrv.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# bcdsrv.dll

**Description:** Boot Configuration Data COM Server
**Type:** dll
**Path:** C:\Windows\System32\bcdsrv.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
