---
name: aeinv.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# aeinv.dll

**Description:** Application Inventory Component
**Type:** dll
**Path:** C:\Windows\System32\aeinv.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
