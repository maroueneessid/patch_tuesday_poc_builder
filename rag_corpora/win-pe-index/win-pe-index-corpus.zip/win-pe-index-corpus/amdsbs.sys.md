---
name: amdsbs.sys
source: pe-index
type: driver
location: drivers
version: 3.7.1540.43 (PART3.121207-1123)
---
# amdsbs.sys

**Description:** AMD Technology AHCI Compatible Controller Driver for Windows - AMD64 platform
**Type:** driver
**Path:** C:\Windows\System32\drivers\amdsbs.sys
**Version:** 3.7.1540.43 (PART3.121207-1123)
**Product:** AMD Technology AHCI Compatible Controller
