---
name: bttflt.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# bttflt.sys

**Description:** VHD BTT Filter Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\bttflt.sys
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
