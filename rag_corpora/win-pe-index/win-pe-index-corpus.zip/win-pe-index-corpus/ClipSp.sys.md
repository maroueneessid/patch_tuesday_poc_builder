---
name: ClipSp.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# ClipSp.sys

**Description:** CLIP Service
**Type:** driver
**Path:** C:\Windows\System32\drivers\ClipSp.sys
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
