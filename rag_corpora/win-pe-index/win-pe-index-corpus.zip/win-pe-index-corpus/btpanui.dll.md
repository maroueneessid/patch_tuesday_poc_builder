---
name: btpanui.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# btpanui.dll

**Description:** Bluetooth PAN User Interface
**Type:** dll
**Path:** C:\Windows\System32\btpanui.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
