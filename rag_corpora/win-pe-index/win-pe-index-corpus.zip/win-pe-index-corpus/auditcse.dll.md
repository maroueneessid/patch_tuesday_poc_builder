---
name: auditcse.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# auditcse.dll

**Description:** Windows Audit Settings CSE
**Type:** dll
**Path:** C:\Windows\System32\auditcse.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
