---
name: appidcertstorecheck.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.3037 (WinBuild.160101.0800)
---
# appidcertstorecheck.exe

**Description:** AppID Certificate Store Verification Task
**Type:** exe
**Path:** C:\Windows\System32\appidcertstorecheck.exe
**Version:** 10.0.26100.3037 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
