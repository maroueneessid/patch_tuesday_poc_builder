---
name: cmstp.exe
source: pe-index
type: exe
location: system32
version: 7.2.26100.1 (WinBuild.160101.0800)
---
# cmstp.exe

**Description:** Microsoft Connection Manager Profile Installer
**Type:** exe
**Path:** C:\Windows\System32\cmstp.exe
**Version:** 7.2.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft(R) Connection Manager
