---
name: cmdl32.exe
source: pe-index
type: exe
location: system32
version: 7.2.26100.1 (WinBuild.160101.0800)
---
# cmdl32.exe

**Description:** Microsoft Connection Manager Auto-Download
**Type:** exe
**Path:** C:\Windows\System32\cmdl32.exe
**Version:** 7.2.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft(R) Connection Manager
