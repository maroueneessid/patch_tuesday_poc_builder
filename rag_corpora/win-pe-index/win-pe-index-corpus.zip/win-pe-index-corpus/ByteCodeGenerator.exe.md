---
name: ByteCodeGenerator.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# ByteCodeGenerator.exe

**Description:** AppX Deployment Bytecode Generator EXE
**Type:** exe
**Path:** C:\Windows\System32\ByteCodeGenerator.exe
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
