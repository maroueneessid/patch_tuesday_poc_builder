---
name: certcli.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# certcli.dll

**Description:** Microsoft® Active Directory Certificate Services Client
**Type:** dll
**Path:** C:\Windows\System32\certcli.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
