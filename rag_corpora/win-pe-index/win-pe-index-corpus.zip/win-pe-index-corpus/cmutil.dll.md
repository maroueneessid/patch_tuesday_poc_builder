---
name: cmutil.dll
source: pe-index
type: dll
location: system32
version: 7.2.26100.1 (WinBuild.160101.0800)
---
# cmutil.dll

**Description:** Microsoft Connection Manager Utility Lib
**Type:** dll
**Path:** C:\Windows\System32\cmutil.dll
**Version:** 7.2.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft(R) Connection Manager
