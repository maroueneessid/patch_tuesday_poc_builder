---
name: bindflt.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.7705 (WinBuild.160101.0800)
---
# bindflt.sys

**Description:** Windows Bind Filter Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\bindflt.sys
**Version:** 10.0.26100.7705 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
