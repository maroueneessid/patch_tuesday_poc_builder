---
name: azroleui.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# azroleui.dll

**Description:** Authorization Manager
**Type:** dll
**Path:** C:\Windows\System32\azroleui.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
