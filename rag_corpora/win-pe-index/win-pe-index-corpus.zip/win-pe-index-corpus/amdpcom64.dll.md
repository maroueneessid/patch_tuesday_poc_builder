---
name: amdpcom64.dll
source: pe-index
type: dll
location: system32
version: 8.14.10.0023
---
# amdpcom64.dll

**Description:** Radeon PCOM Universal Driver
**Type:** dll
**Path:** C:\Windows\System32\amdpcom64.dll
**Version:** 8.14.10.0023
**Product:** Advanced Micro Devices, Inc. Radeon PCOM Universal Driver
