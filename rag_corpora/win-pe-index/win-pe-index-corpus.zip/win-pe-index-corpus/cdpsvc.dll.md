---
name: cdpsvc.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# cdpsvc.dll

**Description:** Microsoft (R) CDP Service
**Type:** dll
**Path:** C:\Windows\System32\cdpsvc.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
