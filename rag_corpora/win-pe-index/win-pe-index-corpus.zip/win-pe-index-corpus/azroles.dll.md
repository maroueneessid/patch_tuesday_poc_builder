---
name: azroles.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# azroles.dll

**Description:** azroles Module
**Type:** dll
**Path:** C:\Windows\System32\azroles.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
