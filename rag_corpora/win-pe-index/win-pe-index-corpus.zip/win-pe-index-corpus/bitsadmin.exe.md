---
name: bitsadmin.exe
source: pe-index
type: exe
location: system32
version: 7.8.26100.1 (WinBuild.160101.0800)
---
# bitsadmin.exe

**Description:** BITS administration utility
**Type:** exe
**Path:** C:\Windows\System32\bitsadmin.exe
**Version:** 7.8.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
