---
name: cmmon32.exe
source: pe-index
type: exe
location: system32
version: 7.2.26100.1 (WinBuild.160101.0800)
---
# cmmon32.exe

**Description:** Microsoft Connection Manager Monitor
**Type:** exe
**Path:** C:\Windows\System32\cmmon32.exe
**Version:** 7.2.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft(R) Connection Manager
