---
name: amdwps.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# amdwps.sys

**Description:** AMD Workload Profiling Scheduling Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\amdwps.sys
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
