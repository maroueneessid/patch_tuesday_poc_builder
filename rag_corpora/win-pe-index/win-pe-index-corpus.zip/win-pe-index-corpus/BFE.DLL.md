---
name: BFE.DLL
source: pe-index
type: other
location: system32
version: 10.0.26100.3915 (WinBuild.160101.0800)
---
# BFE.DLL

**Description:** Base Filtering Engine
**Type:** other
**Path:** C:\Windows\System32\BFE.DLL
**Version:** 10.0.26100.3915 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
