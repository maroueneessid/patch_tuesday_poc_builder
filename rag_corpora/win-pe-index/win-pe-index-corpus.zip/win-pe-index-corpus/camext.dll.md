---
name: camext.dll
source: pe-index
type: dll
location: system32
version: 
---
# camext.dll

**Description:** No description available
**Type:** dll
**Path:** C:\Windows\System32\camext.dll
**Version:** 
**Product:** 
