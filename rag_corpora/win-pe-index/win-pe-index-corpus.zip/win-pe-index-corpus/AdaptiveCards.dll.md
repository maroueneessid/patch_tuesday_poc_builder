---
name: AdaptiveCards.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# AdaptiveCards.dll

**Description:** Windows Adaptive Cards API Server
**Type:** dll
**Path:** C:\Windows\System32\AdaptiveCards.dll
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
