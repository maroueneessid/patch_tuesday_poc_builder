---
name: clrhost.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# clrhost.dll

**Description:** In Proc server for managed servers in the Windows Runtime
**Type:** dll
**Path:** C:\Windows\System32\clrhost.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
