---
name: AuthFWWizFwk.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1
---
# AuthFWWizFwk.dll

**Description:** Wizard Framework
**Type:** dll
**Path:** C:\Windows\System32\AuthFWWizFwk.dll
**Version:** 10.0.26100.1
**Product:** Microsoft (R) Windows (R) Operating System
