---
name: cdd.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7705 (WinBuild.160101.0800)
---
# cdd.dll

**Description:** Canonical Display Driver
**Type:** dll
**Path:** C:\Windows\System32\cdd.dll
**Version:** 10.0.26100.7705 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
