---
name: CameraSettingsUIHost.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# CameraSettingsUIHost.exe

**Description:** Camera Settings UI Host
**Type:** exe
**Path:** C:\Windows\System32\CameraSettingsUIHost.exe
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
