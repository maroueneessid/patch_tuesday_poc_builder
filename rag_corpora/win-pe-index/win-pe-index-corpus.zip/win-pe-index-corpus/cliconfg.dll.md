---
name: cliconfg.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# cliconfg.dll

**Description:** SQL Client Configuration Utility DLL
**Type:** dll
**Path:** C:\Windows\System32\cliconfg.dll
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
