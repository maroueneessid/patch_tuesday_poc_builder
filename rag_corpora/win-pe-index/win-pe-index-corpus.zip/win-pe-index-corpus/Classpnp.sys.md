---
name: Classpnp.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# Classpnp.sys

**Description:** SCSI Class System Dll
**Type:** driver
**Path:** C:\Windows\System32\drivers\Classpnp.sys
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
