---
name: BCP47mrm.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# BCP47mrm.dll

**Description:** BCP47 Language Classes for Resource Management
**Type:** dll
**Path:** C:\Windows\System32\BCP47mrm.dll
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
