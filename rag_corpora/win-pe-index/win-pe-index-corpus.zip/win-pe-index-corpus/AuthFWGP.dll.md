---
name: AuthFWGP.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7705 (WinBuild.160101.0800)
---
# AuthFWGP.dll

**Description:** Windows Defender Firewall with Advanced Security Group Policy Editor Extension
**Type:** dll
**Path:** C:\Windows\System32\AuthFWGP.dll
**Version:** 10.0.26100.7705 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
