---
name: amdhip64_6.dll
source: pe-index
type: dll
location: system32
version: 10.0.3652.0
---
# amdhip64_6.dll

**Description:** AMD Accelerated Parallel Processing amdhip64 6.4 Runtime
**Type:** dll
**Path:** C:\Windows\System32\amdhip64_6.dll
**Version:** 10.0.3652.0
**Product:** amdhip64 6.4 AMD-APP.dbg (3652.0)
