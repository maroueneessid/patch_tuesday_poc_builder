---
name: ActionCenterCPL.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# ActionCenterCPL.dll

**Description:** Security and Maintenance Control Panel
**Type:** dll
**Path:** C:\Windows\System32\ActionCenterCPL.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
