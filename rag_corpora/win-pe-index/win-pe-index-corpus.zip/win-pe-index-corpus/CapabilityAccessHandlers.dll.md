---
name: CapabilityAccessHandlers.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# CapabilityAccessHandlers.dll

**Description:** Capability Access Manager - Handlers' Shared DLL
**Type:** dll
**Path:** C:\Windows\System32\CapabilityAccessHandlers.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
