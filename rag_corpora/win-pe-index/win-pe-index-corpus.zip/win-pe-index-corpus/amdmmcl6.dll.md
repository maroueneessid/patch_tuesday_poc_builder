---
name: amdmmcl6.dll
source: pe-index
type: dll
location: system32
version: 1.6.0
---
# amdmmcl6.dll

**Description:** Radeon MMOCL Universal Driver
**Type:** dll
**Path:** C:\Windows\System32\amdmmcl6.dll
**Version:** 1.6.0
**Product:** Advanced Micro Devices, Inc. Radeon MMOCL Universal Driver
