---
name: AppHostRegistrationVerifier.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# AppHostRegistrationVerifier.exe

**Description:** App Uri Handlers Registration Verifier
**Type:** exe
**Path:** C:\Windows\System32\AppHostRegistrationVerifier.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
