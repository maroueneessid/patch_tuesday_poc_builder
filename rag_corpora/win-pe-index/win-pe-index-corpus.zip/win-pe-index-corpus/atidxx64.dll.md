---
name: atidxx64.dll
source: pe-index
type: dll
location: system32
version: 9.17.11.0082
---
# atidxx64.dll

**Description:** AMD DX11 STUB
**Type:** dll
**Path:** C:\Windows\System32\atidxx64.dll
**Version:** 9.17.11.0082
**Product:** Advanced Micro Devices, Inc. Radeon DirectX 10/11 Driver
