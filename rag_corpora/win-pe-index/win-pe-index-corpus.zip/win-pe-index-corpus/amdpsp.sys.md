---
name: amdpsp.sys
source: pe-index
type: driver
location: drivers
version: 5.42.0.0
---
# amdpsp.sys

**Description:** amdpsp sys
**Type:** driver
**Path:** C:\Windows\System32\drivers\amdpsp.sys
**Version:** 5.42.0.0
**Product:** Advanced Micro Devices, Inc. amdpsp sys
