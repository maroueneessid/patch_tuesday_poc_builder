---
name: adprovider.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# adprovider.dll

**Description:** adprovider DLL
**Type:** dll
**Path:** C:\Windows\System32\adprovider.dll
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
