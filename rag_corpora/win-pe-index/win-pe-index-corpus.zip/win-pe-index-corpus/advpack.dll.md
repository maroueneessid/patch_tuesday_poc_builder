---
name: advpack.dll
source: pe-index
type: dll
location: system32
version: 11.00.26100.1 (WinBuild.160101.0800)
---
# advpack.dll

**Description:** ADVPACK
**Type:** dll
**Path:** C:\Windows\System32\advpack.dll
**Version:** 11.00.26100.1 (WinBuild.160101.0800)
**Product:** Internet Explorer
