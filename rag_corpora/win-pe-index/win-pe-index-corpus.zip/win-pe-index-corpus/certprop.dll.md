---
name: certprop.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.3323 (WinBuild.160101.0800)
---
# certprop.dll

**Description:** Microsoft Smartcard Certificate Propagation Service
**Type:** dll
**Path:** C:\Windows\System32\certprop.dll
**Version:** 10.0.26100.3323 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
