---
name: bderepair.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.4768 (WinBuild.160101.0800)
---
# bderepair.dll

**Description:** BitLocker Drive Encryption: Drive Repair Tool
**Type:** dll
**Path:** C:\Windows\System32\bderepair.dll
**Version:** 10.0.26100.4768 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
