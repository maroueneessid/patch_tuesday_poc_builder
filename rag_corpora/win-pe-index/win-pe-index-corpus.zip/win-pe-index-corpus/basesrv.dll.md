---
name: basesrv.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# basesrv.dll

**Description:** Windows NT BASE API Server DLL
**Type:** dll
**Path:** C:\Windows\System32\basesrv.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
