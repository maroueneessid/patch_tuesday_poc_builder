---
name: AuthFWSnapin.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920
---
# AuthFWSnapin.dll

**Description:** Microsoft.WindowsFirewall.SnapIn
**Type:** dll
**Path:** C:\Windows\System32\AuthFWSnapin.dll
**Version:** 10.0.26100.7920
**Product:** Microsoft (R) Windows (R) Operating System
