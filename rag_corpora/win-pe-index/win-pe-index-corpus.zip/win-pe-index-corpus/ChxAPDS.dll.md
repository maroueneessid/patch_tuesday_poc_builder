---
name: ChxAPDS.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# ChxAPDS.dll

**Description:** "ChxAPDS.DYNLINK"
**Type:** dll
**Path:** C:\Windows\System32\ChxAPDS.dll
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
