---
name: acppage.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.4768 (WinBuild.160101.0800)
---
# acppage.dll

**Description:** Compatibility Tab Shell Extension Library
**Type:** dll
**Path:** C:\Windows\System32\acppage.dll
**Version:** 10.0.26100.4768 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
