---
name: cnghwassist.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# cnghwassist.sys

**Description:** CNG Hardware Assist algorithm provider
**Type:** driver
**Path:** C:\Windows\System32\drivers\cnghwassist.sys
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
