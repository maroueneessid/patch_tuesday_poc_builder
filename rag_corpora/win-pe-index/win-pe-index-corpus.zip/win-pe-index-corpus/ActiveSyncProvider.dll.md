---
name: ActiveSyncProvider.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# ActiveSyncProvider.dll

**Description:** The engine that syncs ActiveSync accounts
**Type:** dll
**Path:** C:\Windows\System32\ActiveSyncProvider.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
