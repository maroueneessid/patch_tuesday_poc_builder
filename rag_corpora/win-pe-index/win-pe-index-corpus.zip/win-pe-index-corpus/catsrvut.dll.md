---
name: catsrvut.dll
source: pe-index
type: dll
location: system32
version: 2001.12.10941.16384 (WinBuild.160101.0800)
---
# catsrvut.dll

**Description:** COM+ Configuration Catalog Server Utilities
**Type:** dll
**Path:** C:\Windows\System32\catsrvut.dll
**Version:** 2001.12.10941.16384 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
