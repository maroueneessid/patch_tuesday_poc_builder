---
name: arcsas.sys
source: pe-index
type: driver
location: drivers
version: 7.5.0.32048 (NT.150223-1854)
---
# arcsas.sys

**Description:** Adaptec SAS RAID WS03 Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\arcsas.sys
**Version:** 7.5.0.32048 (NT.150223-1854)
**Product:** Adaptec RAID Controller
