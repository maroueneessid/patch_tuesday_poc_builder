---
name: bthudtask.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# bthudtask.exe

**Description:** Bluetooth Uninstall Device Task
**Type:** exe
**Path:** C:\Windows\System32\bthudtask.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
