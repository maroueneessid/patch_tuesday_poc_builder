---
name: amdxata.sys
source: pe-index
type: driver
location: drivers
version: 1.1.3.277 (NT.150223-1854)
---
# amdxata.sys

**Description:** Storage Filter Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\amdxata.sys
**Version:** 1.1.3.277 (NT.150223-1854)
**Product:** Storage Filter Driver
