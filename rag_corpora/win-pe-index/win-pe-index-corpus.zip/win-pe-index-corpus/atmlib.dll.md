---
name: atmlib.dll
source: pe-index
type: dll
location: system32
version: 5.1 Build 254
---
# atmlib.dll

**Description:** Windows NT OpenType/Type 1 API Library.
**Type:** dll
**Path:** C:\Windows\System32\atmlib.dll
**Version:** 5.1 Build 254
**Product:** Adobe Type Manager
