---
name: amdadlx64.dll
source: pe-index
type: dll
location: system32
version: 1.4.0.121
---
# amdadlx64.dll

**Description:** ADLX
**Type:** dll
**Path:** C:\Windows\System32\amdadlx64.dll
**Version:** 1.4.0.121
**Product:** ADLX Component
