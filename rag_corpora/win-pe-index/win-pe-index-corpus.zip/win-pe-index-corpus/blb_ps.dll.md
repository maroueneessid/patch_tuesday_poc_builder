---
name: blb_ps.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# blb_ps.dll

**Description:** Microsoft® Block Level Backup proxy/stub
**Type:** dll
**Path:** C:\Windows\System32\blb_ps.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
