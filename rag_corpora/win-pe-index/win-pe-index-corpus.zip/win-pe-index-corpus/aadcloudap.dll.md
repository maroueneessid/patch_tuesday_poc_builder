---
name: aadcloudap.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# aadcloudap.dll

**Description:** Microsoft Entra Cloud AP Plugin
**Type:** dll
**Path:** C:\Windows\System32\aadcloudap.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
