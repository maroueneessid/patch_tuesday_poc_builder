---
name: BOOTVID.DLL
source: pe-index
type: other
location: system32
version: 10.0.26100.4202 (WinBuild.160101.0800)
---
# BOOTVID.DLL

**Description:** VGA Boot Driver
**Type:** other
**Path:** C:\Windows\System32\BOOTVID.DLL
**Version:** 10.0.26100.4202 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
