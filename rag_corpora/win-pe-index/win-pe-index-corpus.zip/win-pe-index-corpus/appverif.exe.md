---
name: appverif.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.4948 (WinBuild.160101.0800)
---
# appverif.exe

**Description:** Application Verifier User Interface Utility
**Type:** exe
**Path:** C:\Windows\System32\appverif.exe
**Version:** 10.0.26100.4948 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
