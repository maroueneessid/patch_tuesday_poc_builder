---
name: appidtel.exe
source: pe-index
type: exe
location: system32
version: 1.00 (WinBuild.160101.0800)
---
# appidtel.exe

**Description:** Initializes Appid ManagedInstaller and Smartscreen Telemetry
**Type:** exe
**Path:** C:\Windows\System32\appidtel.exe
**Version:** 1.00 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
