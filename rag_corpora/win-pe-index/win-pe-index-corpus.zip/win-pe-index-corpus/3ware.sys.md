---
name: 3ware.sys
source: pe-index
type: driver
location: drivers
version: 5.01.00.051
---
# 3ware.sys

**Description:** LSI 3ware SCSI Storport Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\3ware.sys
**Version:** 5.01.00.051
**Product:** LSI 3ware RAID Controller
