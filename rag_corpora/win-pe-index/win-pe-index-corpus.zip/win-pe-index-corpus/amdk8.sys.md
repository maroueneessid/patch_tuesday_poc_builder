---
name: amdk8.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# amdk8.sys

**Description:** Processor Device Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\amdk8.sys
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
