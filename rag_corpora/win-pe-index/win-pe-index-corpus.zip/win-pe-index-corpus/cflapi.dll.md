---
name: cflapi.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# cflapi.dll

**Description:** CXH from LogonUI API
**Type:** dll
**Path:** C:\Windows\System32\cflapi.dll
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
