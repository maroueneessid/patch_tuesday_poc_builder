---
name: Chakra.dll
source: pe-index
type: dll
location: system32
version: 11.00.26100.7920 (WinBuild.160101.0800)
---
# Chakra.dll

**Description:** Microsoft ® Chakra (Private)
**Type:** dll
**Path:** C:\Windows\System32\Chakra.dll
**Version:** 11.00.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft ® Chakra
