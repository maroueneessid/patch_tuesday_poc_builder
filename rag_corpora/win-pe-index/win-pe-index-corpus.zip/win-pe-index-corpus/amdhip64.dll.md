---
name: amdhip64.dll
source: pe-index
type: dll
location: system32
version: 10.0.3592.0
---
# amdhip64.dll

**Description:** AMD Accelerated Parallel Processing amdhip64 5.7 Runtime
**Type:** dll
**Path:** C:\Windows\System32\amdhip64.dll
**Version:** 10.0.3592.0
**Product:** amdhip64 5.7 AMD-APP.dbg (3592.0)
