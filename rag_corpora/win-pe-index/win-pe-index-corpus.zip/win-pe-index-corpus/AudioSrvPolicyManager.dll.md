---
name: AudioSrvPolicyManager.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# AudioSrvPolicyManager.dll

**Description:** Windows Audio Service Policy Manager
**Type:** dll
**Path:** C:\Windows\System32\AudioSrvPolicyManager.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
