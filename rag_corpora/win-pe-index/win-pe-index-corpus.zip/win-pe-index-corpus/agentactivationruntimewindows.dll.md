---
name: agentactivationruntimewindows.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7705 (WinBuild.160101.0800)
---
# agentactivationruntimewindows.dll

**Description:** Agent Activation Runtime Windows DLL
**Type:** dll
**Path:** C:\Windows\System32\agentactivationruntimewindows.dll
**Version:** 10.0.26100.7705 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
