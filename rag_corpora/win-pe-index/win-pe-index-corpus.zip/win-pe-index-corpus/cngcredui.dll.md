---
name: cngcredui.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# cngcredui.dll

**Description:** Microsoft CNG CredUI Provider
**Type:** dll
**Path:** C:\Windows\System32\cngcredui.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
