---
name: bfs.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# bfs.sys

**Description:** Bfs Filter Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\bfs.sys
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
