---
name: alg.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# alg.exe

**Description:** Application Layer Gateway Service
**Type:** exe
**Path:** C:\Windows\System32\alg.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
