---
name: bxvbda.sys
source: pe-index
type: driver
location: drivers
version: 7.12.31.105
---
# bxvbda.sys

**Description:** QLogic Gigabit Ethernet VBD
**Type:** driver
**Path:** C:\Windows\System32\drivers\bxvbda.sys
**Version:** 7.12.31.105
**Product:** QLogic Gigabit Ethernet
