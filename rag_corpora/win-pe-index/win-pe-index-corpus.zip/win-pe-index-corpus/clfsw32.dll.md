---
name: clfsw32.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# clfsw32.dll

**Description:** Common Log Marshalling Win32 DLL
**Type:** dll
**Path:** C:\Windows\System32\clfsw32.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
