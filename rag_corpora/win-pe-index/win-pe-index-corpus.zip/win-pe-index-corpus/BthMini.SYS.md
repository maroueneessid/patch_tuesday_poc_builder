---
name: BthMini.SYS
source: pe-index
type: other
location: drivers
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# BthMini.SYS

**Description:** Bluetooth Transport Extensibility Miniport Driver
**Type:** other
**Path:** C:\Windows\System32\drivers\BthMini.SYS
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
