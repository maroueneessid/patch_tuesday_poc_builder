---
name: CloudExperienceHostBroker.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# CloudExperienceHostBroker.exe

**Description:** CloudExperienceHost Broker
**Type:** exe
**Path:** C:\Windows\System32\CloudExperienceHostBroker.exe
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
