---
name: ClipRenew.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# ClipRenew.exe

**Description:** Acquire License From Store
**Type:** exe
**Path:** C:\Windows\System32\ClipRenew.exe
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
