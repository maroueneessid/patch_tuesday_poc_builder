---
name: ACPBackgroundManagerPolicy.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7705 (WinBuild.160101.0800)
---
# ACPBackgroundManagerPolicy.dll

**Description:** <d> ACP Background Manager Policy DLL
**Type:** dll
**Path:** C:\Windows\System32\ACPBackgroundManagerPolicy.dll
**Version:** 10.0.26100.7705 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
