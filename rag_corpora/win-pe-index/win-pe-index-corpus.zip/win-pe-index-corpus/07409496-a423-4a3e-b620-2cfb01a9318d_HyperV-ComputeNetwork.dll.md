---
name: 07409496-a423-4a3e-b620-2cfb01a9318d_HyperV-ComputeNetwork.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7705 (WinBuild.160101.0800)
---
# 07409496-a423-4a3e-b620-2cfb01a9318d_HyperV-ComputeNetwork.dll

**Description:** ApiSet Schema Extension DLL
**Type:** dll
**Path:** C:\Windows\System32\07409496-a423-4a3e-b620-2cfb01a9318d_HyperV-ComputeNetwork.dll
**Version:** 10.0.26100.7705 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
