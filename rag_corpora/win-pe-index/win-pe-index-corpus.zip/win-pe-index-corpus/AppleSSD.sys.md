---
name: AppleSSD.sys
source: pe-index
type: driver
location: drivers
version: 6.1.7800.1
---
# AppleSSD.sys

**Description:** Apple Solid State Drive Device
**Type:** driver
**Path:** C:\Windows\System32\drivers\AppleSSD.sys
**Version:** 6.1.7800.1
**Product:** Boot Camp
