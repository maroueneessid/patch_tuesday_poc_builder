---
name: AUDIOKSE.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.8036 (WinBuild.160101.0800)
---
# AUDIOKSE.dll

**Description:** Audio Ks Endpoint
**Type:** dll
**Path:** C:\Windows\System32\AUDIOKSE.dll
**Version:** 10.0.26100.8036 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
