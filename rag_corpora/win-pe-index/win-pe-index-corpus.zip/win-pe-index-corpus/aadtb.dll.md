---
name: aadtb.dll
source: pe-index
type: dll
location: system32
version: 10.0.10011.16384 (WinBuild.160101.0800)
---
# aadtb.dll

**Description:** Microsoft Entra WAM Helper Library
**Type:** dll
**Path:** C:\Windows\System32\aadtb.dll
**Version:** 10.0.10011.16384 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
