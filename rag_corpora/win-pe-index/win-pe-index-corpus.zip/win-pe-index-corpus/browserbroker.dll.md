---
name: browserbroker.dll
source: pe-index
type: dll
location: system32
version: 11.00.26100.7309 (WinBuild.160101.0800)
---
# browserbroker.dll

**Description:** BrowserBroker
**Type:** dll
**Path:** C:\Windows\System32\browserbroker.dll
**Version:** 11.00.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
