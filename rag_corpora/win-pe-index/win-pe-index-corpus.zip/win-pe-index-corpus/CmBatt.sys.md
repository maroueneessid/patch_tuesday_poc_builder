---
name: CmBatt.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# CmBatt.sys

**Description:** Control Method Battery Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\CmBatt.sys
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
