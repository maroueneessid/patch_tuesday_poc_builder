---
name: cmdkey.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# cmdkey.exe

**Description:** Credential Manager Command Line Utility
**Type:** exe
**Path:** C:\Windows\System32\cmdkey.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
