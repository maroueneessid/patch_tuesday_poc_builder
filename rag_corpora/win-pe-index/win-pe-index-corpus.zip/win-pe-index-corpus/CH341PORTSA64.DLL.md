---
name: CH341PORTSA64.DLL
source: pe-index
type: other
location: system32
version: 1, 3, 0, 0
---
# CH341PORTSA64.DLL

**Description:** CH341 Serial port preperty sheet
**Type:** other
**Path:** C:\Windows\System32\CH341PORTSA64.DLL
**Version:** 1, 3, 0, 0
**Product:** CH341PORTS
