---
name: charmap.exe
source: pe-index
type: exe
location: system32
version: 5.2.3668.0
---
# charmap.exe

**Description:** Character Map
**Type:** exe
**Path:** C:\Windows\System32\charmap.exe
**Version:** 5.2.3668.0
**Product:** MicrosoftÂ® WindowsÂ® Operating System
