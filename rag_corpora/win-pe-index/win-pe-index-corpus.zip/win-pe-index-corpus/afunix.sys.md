---
name: afunix.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.6725 (WinBuild.160101.0800)
---
# afunix.sys

**Description:** AF_UNIX socket provider
**Type:** driver
**Path:** C:\Windows\System32\drivers\afunix.sys
**Version:** 10.0.26100.6725 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
