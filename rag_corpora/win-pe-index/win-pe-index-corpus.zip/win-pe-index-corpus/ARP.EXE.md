---
name: ARP.EXE
source: pe-index
type: other
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# ARP.EXE

**Description:** TCP/IP Arp Command
**Type:** other
**Path:** C:\Windows\System32\ARP.EXE
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
