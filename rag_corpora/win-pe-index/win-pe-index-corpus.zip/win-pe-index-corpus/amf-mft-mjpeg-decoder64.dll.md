---
name: amf-mft-mjpeg-decoder64.dll
source: pe-index
type: dll
location: system32
version: 1.0.0.0
---
# amf-mft-mjpeg-decoder64.dll

**Description:** AMD MJPEG MFT Component
**Type:** dll
**Path:** C:\Windows\System32\amf-mft-mjpeg-decoder64.dll
**Version:** 1.0.0.0
**Product:** AMF MFT MJPEG Decoder
