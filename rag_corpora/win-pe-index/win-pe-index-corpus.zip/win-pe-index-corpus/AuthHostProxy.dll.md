---
name: AuthHostProxy.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7019 (WinBuild.160101.0800)
---
# AuthHostProxy.dll

**Description:** Web Authentication Host Proxy
**Type:** dll
**Path:** C:\Windows\System32\AuthHostProxy.dll
**Version:** 10.0.26100.7019 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
