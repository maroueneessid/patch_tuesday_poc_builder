---
name: AppExtension.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# AppExtension.dll

**Description:** PackageExtension and AppExtension APIs
**Type:** dll
**Path:** C:\Windows\System32\AppExtension.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
