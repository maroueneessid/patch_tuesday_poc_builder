---
name: amdsasrv64.dll
source: pe-index
type: dll
location: system32
version: 
---
# amdsasrv64.dll

**Description:** No description available
**Type:** dll
**Path:** C:\Windows\System32\amdsasrv64.dll
**Version:** 
**Product:** 
