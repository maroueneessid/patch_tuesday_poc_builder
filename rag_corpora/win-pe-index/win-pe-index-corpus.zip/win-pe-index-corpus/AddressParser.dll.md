---
name: AddressParser.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1882 (WinBuild.160101.0800)
---
# AddressParser.dll

**Description:** ADDRESSPARSER
**Type:** dll
**Path:** C:\Windows\System32\AddressParser.dll
**Version:** 10.0.26100.1882 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
