---
name: cht4vfx.sys
source: pe-index
type: driver
location: drivers
version: 6.11.4.100
---
# cht4vfx.sys

**Description:** VF library for Chelsio ® T5/T6 Chipset
**Type:** driver
**Path:** C:\Windows\System32\drivers\cht4vfx.sys
**Version:** 6.11.4.100
**Product:** Chelsio Communications Unified Network I/O Controller
