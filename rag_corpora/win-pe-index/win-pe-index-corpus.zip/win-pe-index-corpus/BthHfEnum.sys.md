---
name: BthHfEnum.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# BthHfEnum.sys

**Description:** Bluetooth Hands-Free Audio and Call Control HID Enumerator
**Type:** driver
**Path:** C:\Windows\System32\drivers\BthHfEnum.sys
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
