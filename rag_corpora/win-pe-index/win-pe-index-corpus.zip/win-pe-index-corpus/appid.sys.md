---
name: appid.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# appid.sys

**Description:** AppID Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\appid.sys
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
