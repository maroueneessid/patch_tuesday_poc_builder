---
name: acproxy.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# acproxy.dll

**Description:** Autochk Proxy DLL
**Type:** dll
**Path:** C:\Windows\System32\acproxy.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
