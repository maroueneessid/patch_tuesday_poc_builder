---
name: cmimcext.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.8037 (WinBuild.160101.0800)
---
# cmimcext.sys

**Description:** Kernel Configuration Manager Initial Configuration Extension Host Export Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\cmimcext.sys
**Version:** 10.0.26100.8037 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
