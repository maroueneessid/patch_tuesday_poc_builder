---
name: cimfs.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# cimfs.dll

**Description:** CimFS user mode API
**Type:** dll
**Path:** C:\Windows\System32\cimfs.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
