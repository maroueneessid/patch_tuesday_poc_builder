---
name: BtaMPM.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.5074 (WinBuild.160101.0800)
---
# BtaMPM.sys

**Description:** Microsoft Bluetooth Audio Multiprofile Manager
**Type:** driver
**Path:** C:\Windows\System32\drivers\BtaMPM.sys
**Version:** 10.0.26100.5074 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
