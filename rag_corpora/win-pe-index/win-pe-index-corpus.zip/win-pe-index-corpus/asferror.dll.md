---
name: asferror.dll
source: pe-index
type: dll
location: system32
version: 12.0.26100.1 (WinBuild.160101.0800)
---
# asferror.dll

**Description:** ASF Error Definitions
**Type:** dll
**Path:** C:\Windows\System32\asferror.dll
**Version:** 12.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
