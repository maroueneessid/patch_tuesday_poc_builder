---
name: atidemgy.dll
source: pe-index
type: dll
location: system32
version: 4.5.9504.21352
---
# atidemgy.dll

**Description:** Graphics DEM
**Type:** dll
**Path:** C:\Windows\System32\atidemgy.dll
**Version:** 4.5.9504.21352
**Product:** Catalyst® Control Centre
