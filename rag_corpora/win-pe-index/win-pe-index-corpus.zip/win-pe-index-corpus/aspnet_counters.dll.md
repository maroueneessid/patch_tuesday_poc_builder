---
name: aspnet_counters.dll
source: pe-index
type: dll
location: system32
version: 4.8.9221.0 built by: NET481REL1LAST_25H2
---
# aspnet_counters.dll

**Description:** Microsoft ASP.NET Performance Counter Shim DLL
**Type:** dll
**Path:** C:\Windows\System32\aspnet_counters.dll
**Version:** 4.8.9221.0 built by: NET481REL1LAST_25H2
**Product:** Microsoft® .NET Framework
