---
name: agilevpn.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# agilevpn.sys

**Description:** RAS Agile Vpn Miniport Call Manager
**Type:** driver
**Path:** C:\Windows\System32\drivers\agilevpn.sys
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
