---
name: amdtee_api.dll
source: pe-index
type: dll
location: system32
version: 5.42.0.0
---
# amdtee_api.dll

**Description:** amdtee_api dll
**Type:** dll
**Path:** C:\Windows\System32\amdtee_api.dll
**Version:** 5.42.0.0
**Product:** Advanced Micro Devices, Inc. amdtee_api dll
