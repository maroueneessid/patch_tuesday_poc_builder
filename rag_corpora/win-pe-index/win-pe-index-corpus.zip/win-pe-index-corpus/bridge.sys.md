---
name: bridge.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.2454 (WinBuild.160101.0800)
---
# bridge.sys

**Description:** MAC Bridge Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\bridge.sys
**Version:** 10.0.26100.2454 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
