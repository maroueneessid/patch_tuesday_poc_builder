---
name: AcpiDev.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.6725 (WinBuild.160101.0800)
---
# AcpiDev.sys

**Description:** ACPI Devices Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\AcpiDev.sys
**Version:** 10.0.26100.6725 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
