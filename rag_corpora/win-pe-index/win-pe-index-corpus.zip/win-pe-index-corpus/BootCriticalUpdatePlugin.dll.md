---
name: BootCriticalUpdatePlugin.dll
source: pe-index
type: dll
location: system32
version: 1.0.0.1
---
# BootCriticalUpdatePlugin.dll

**Description:** BootCriticalUpdate Plugin for WinRE boot failure scenario
**Type:** dll
**Path:** C:\Windows\System32\BootCriticalUpdatePlugin.dll
**Version:** 1.0.0.1
**Product:** BootCriticalUpdate
