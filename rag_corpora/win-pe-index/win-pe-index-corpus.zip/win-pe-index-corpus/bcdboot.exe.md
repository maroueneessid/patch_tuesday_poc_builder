---
name: bcdboot.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# bcdboot.exe

**Description:** Bcdboot utility
**Type:** exe
**Path:** C:\Windows\System32\bcdboot.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
