---
name: cdfs.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# cdfs.sys

**Description:** CD-ROM File System Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\cdfs.sys
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
