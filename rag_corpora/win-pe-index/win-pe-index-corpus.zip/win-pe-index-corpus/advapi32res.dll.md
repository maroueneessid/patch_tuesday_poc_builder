---
name: advapi32res.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# advapi32res.dll

**Description:** Advanced Windows 32 Base API
**Type:** dll
**Path:** C:\Windows\System32\advapi32res.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
