---
name: cabview.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# cabview.dll

**Description:** Cabinet File Viewer Shell Extension
**Type:** dll
**Path:** C:\Windows\System32\cabview.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
