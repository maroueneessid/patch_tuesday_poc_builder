---
name: amdgpio3.sys
source: pe-index
type: driver
location: drivers
version: 3.0.3.0000
---
# amdgpio3.sys

**Description:** AMD GPIO Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\amdgpio3.sys
**Version:** 3.0.3.0000
**Product:** AMD GPIO Controller Driver
