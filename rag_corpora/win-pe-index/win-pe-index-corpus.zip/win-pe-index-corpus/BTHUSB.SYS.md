---
name: BTHUSB.SYS
source: pe-index
type: other
location: drivers
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# BTHUSB.SYS

**Description:** Bluetooth Miniport Driver
**Type:** other
**Path:** C:\Windows\System32\drivers\BTHUSB.SYS
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
