---
name: ClipUpgrade.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# ClipUpgrade.exe

**Description:** Upgrade To Windows Professional Education
**Type:** exe
**Path:** C:\Windows\System32\ClipUpgrade.exe
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
