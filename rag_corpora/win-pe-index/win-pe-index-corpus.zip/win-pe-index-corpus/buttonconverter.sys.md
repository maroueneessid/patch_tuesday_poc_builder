---
name: buttonconverter.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.4484 (WinBuild.160101.0800)
---
# buttonconverter.sys

**Description:** Button Converter Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\buttonconverter.sys
**Version:** 10.0.26100.4484 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
