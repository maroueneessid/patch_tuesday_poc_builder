---
name: AudioEng.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.8036 (WinBuild.160101.0800)
---
# AudioEng.dll

**Description:** Audio Engine
**Type:** dll
**Path:** C:\Windows\System32\AudioEng.dll
**Version:** 10.0.26100.8036 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
