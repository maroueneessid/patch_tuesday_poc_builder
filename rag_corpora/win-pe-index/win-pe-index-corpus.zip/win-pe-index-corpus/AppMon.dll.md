---
name: AppMon.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# AppMon.dll

**Description:** App Printer
**Type:** dll
**Path:** C:\Windows\System32\AppMon.dll
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
