---
name: ANR-bgproc-Lib.dll
source: pe-index
type: dll
location: system32
version: 1.0.0.1
---
# ANR-bgproc-Lib.dll

**Description:** BG task interface
**Type:** dll
**Path:** C:\Windows\System32\ANR-bgproc-Lib.dll
**Version:** 1.0.0.1
**Product:** AMD Noise Suppression
