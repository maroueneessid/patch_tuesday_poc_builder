---
name: ActionQueue.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# ActionQueue.dll

**Description:** Unattend Action Queue Generator / Executor
**Type:** dll
**Path:** C:\Windows\System32\ActionQueue.dll
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
