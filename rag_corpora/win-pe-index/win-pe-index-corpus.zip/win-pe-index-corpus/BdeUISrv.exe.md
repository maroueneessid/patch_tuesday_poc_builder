---
name: BdeUISrv.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.7019 (WinBuild.160101.0800)
---
# BdeUISrv.exe

**Description:** BDE UI Launcher
**Type:** exe
**Path:** C:\Windows\System32\BdeUISrv.exe
**Version:** 10.0.26100.7019 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
