---
name: AboutSettingsHandlers.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# AboutSettingsHandlers.dll

**Description:** System Settings About Handlers Implementation
**Type:** dll
**Path:** C:\Windows\System32\AboutSettingsHandlers.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
