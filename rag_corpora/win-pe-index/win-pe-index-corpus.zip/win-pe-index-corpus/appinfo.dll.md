---
name: appinfo.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.6725 (WinBuild.160101.0800)
---
# appinfo.dll

**Description:** Application Information Service
**Type:** dll
**Path:** C:\Windows\System32\appinfo.dll
**Version:** 10.0.26100.6725 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
