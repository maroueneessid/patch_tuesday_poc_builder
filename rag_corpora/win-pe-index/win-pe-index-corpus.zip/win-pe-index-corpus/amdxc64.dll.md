---
name: amdxc64.dll
source: pe-index
type: dll
location: system32
version: 
---
# amdxc64.dll

**Description:** No description available
**Type:** dll
**Path:** C:\Windows\System32\amdxc64.dll
**Version:** 
**Product:** 
