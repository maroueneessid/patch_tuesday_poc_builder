---
name: BackgroundTransferHost.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# BackgroundTransferHost.exe

**Description:** Download/Upload Host
**Type:** exe
**Path:** C:\Windows\System32\BackgroundTransferHost.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
