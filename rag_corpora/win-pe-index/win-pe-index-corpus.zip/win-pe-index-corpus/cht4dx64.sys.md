---
name: cht4dx64.sys
source: pe-index
type: driver
location: drivers
version: 6.11.4.100
---
# cht4dx64.sys

**Description:** Chelsio iSCSI Crash Dump Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\cht4dx64.sys
**Version:** 6.11.4.100
**Product:** Chelsio Communications iSCSI Crash Dump Driver
