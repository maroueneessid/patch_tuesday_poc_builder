---
name: acpi.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# acpi.sys

**Description:** ACPI Driver for NT
**Type:** driver
**Path:** C:\Windows\System32\drivers\acpi.sys
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
