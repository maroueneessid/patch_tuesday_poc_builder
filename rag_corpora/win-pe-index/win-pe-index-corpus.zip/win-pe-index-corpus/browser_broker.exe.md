---
name: browser_broker.exe
source: pe-index
type: exe
location: system32
version: 11.00.26100.7309 (WinBuild.160101.0800)
---
# browser_broker.exe

**Description:** Browser_Broker
**Type:** exe
**Path:** C:\Windows\System32\browser_broker.exe
**Version:** 11.00.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
