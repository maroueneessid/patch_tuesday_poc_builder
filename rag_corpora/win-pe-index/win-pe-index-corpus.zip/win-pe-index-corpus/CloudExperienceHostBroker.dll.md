---
name: CloudExperienceHostBroker.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# CloudExperienceHostBroker.dll

**Description:** CloudExperienceHostBroker
**Type:** dll
**Path:** C:\Windows\System32\CloudExperienceHostBroker.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
