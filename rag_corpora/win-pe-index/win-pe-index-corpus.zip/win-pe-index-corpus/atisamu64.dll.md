---
name: atisamu64.dll
source: pe-index
type: dll
location: system32
version: 7.1.0.1
---
# atisamu64.dll

**Description:** Radeon spu api dll
**Type:** dll
**Path:** C:\Windows\System32\atisamu64.dll
**Version:** 7.1.0.1
**Product:** Advanced Micro Devices, Inc. Radeon spu api dll
