---
name: BitsProxy.dll
source: pe-index
type: dll
location: system32
version: 7.8.26100.5074 (WinBuild.160101.0800)
---
# BitsProxy.dll

**Description:** Background Intelligent Transfer Service Proxy
**Type:** dll
**Path:** C:\Windows\System32\BitsProxy.dll
**Version:** 7.8.26100.5074 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
