---
name: cdosys.dll
source: pe-index
type: dll
location: system32
version: 6.6.26100.1 (WinBuild.160101.0800)
---
# cdosys.dll

**Description:** Microsoft CDO for Windows Library
**Type:** dll
**Path:** C:\Windows\System32\cdosys.dll
**Version:** 6.6.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
