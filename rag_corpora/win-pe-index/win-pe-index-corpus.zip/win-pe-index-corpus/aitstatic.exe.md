---
name: aitstatic.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# aitstatic.exe

**Description:** Application Impact Telemetry Static Analyzer
**Type:** exe
**Path:** C:\Windows\System32\aitstatic.exe
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
