---
name: cmifw.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.8036 (WinBuild.160101.0800)
---
# cmifw.dll

**Description:** Windows Defender Firewall rule configuration plug-in
**Type:** dll
**Path:** C:\Windows\System32\cmifw.dll
**Version:** 10.0.26100.8036 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
