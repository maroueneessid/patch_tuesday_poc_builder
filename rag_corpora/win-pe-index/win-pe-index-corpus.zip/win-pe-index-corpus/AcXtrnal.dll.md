---
name: AcXtrnal.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.2454 (WinBuild.160101.0800)
---
# AcXtrnal.dll

**Description:** Windows Compatibility DLL
**Type:** dll
**Path:** C:\Windows\System32\AcXtrnal.dll
**Version:** 10.0.26100.2454 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
