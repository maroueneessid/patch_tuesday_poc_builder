---
name: CiTool.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1000 (WinBuild.160101.0800)
---
# CiTool.exe

**Description:** CodeIntegrity Generic Tool
**Type:** exe
**Path:** C:\Windows\System32\CiTool.exe
**Version:** 10.0.26100.1000 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
