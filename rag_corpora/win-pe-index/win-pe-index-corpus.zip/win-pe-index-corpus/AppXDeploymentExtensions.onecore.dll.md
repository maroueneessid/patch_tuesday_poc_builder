---
name: AppXDeploymentExtensions.onecore.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# AppXDeploymentExtensions.onecore.dll

**Description:** AppX Deployment Extensions OneCore DLL
**Type:** dll
**Path:** C:\Windows\System32\AppXDeploymentExtensions.onecore.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
