---
name: archiveint.dll
source: pe-index
type: dll
location: system32
version: 3.8.4 (WinBuild.160101.0800)
---
# archiveint.dll

**Description:** Windows-internal libarchive library
**Type:** dll
**Path:** C:\Windows\System32\archiveint.dll
**Version:** 3.8.4 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
