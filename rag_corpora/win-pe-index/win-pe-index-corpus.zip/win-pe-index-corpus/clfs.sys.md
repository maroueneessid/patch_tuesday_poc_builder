---
name: clfs.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# clfs.sys

**Description:** Common Log File System Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\clfs.sys
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
