---
name: adp80xx.sys
source: pe-index
type: driver
location: drivers
version: 1.3.0.10769 (NT.150223-1854)
---
# adp80xx.sys

**Description:** PMC-Sierra Storport  Driver For SPC8x6G SAS/SATA controller
**Type:** driver
**Path:** C:\Windows\System32\drivers\adp80xx.sys
**Version:** 1.3.0.10769 (NT.150223-1854)
**Product:** PMC-Sierra HBA Controller
