---
name: ApplicationTargetedFeatureDatabase.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# ApplicationTargetedFeatureDatabase.dll

**Description:** ApplicationTargetedFeatureDatabase
**Type:** dll
**Path:** C:\Windows\System32\ApplicationTargetedFeatureDatabase.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
