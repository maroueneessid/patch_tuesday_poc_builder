---
name: amd_comgr_2.dll
source: pe-index
type: dll
location: system32
version: 
---
# amd_comgr_2.dll

**Description:** No description available
**Type:** dll
**Path:** C:\Windows\System32\amd_comgr_2.dll
**Version:** 
**Product:** 
