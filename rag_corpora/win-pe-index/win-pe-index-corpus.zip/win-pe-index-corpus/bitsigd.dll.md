---
name: bitsigd.dll
source: pe-index
type: dll
location: system32
version: 7.8.26100.1150 (WinBuild.160101.0800)
---
# bitsigd.dll

**Description:** Background Intelligent Transfer Service IGD Support
**Type:** dll
**Path:** C:\Windows\System32\bitsigd.dll
**Version:** 7.8.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
