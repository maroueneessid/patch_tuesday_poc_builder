---
name: apisetschema.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7705 (WinBuild.160101.0800)
---
# apisetschema.dll

**Description:** ApiSet Schema DLL
**Type:** dll
**Path:** C:\Windows\System32\apisetschema.dll
**Version:** 10.0.26100.7705 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
