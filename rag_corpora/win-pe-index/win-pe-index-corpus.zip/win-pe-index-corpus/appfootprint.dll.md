---
name: appfootprint.dll
source: pe-index
type: dll
location: system32
version: 
---
# appfootprint.dll

**Description:** No description available
**Type:** dll
**Path:** C:\Windows\System32\appfootprint.dll
**Version:** 
**Product:** 
