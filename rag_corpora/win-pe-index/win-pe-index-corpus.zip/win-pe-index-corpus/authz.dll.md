---
name: authz.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# authz.dll

**Description:** Authorization Framework
**Type:** dll
**Path:** C:\Windows\System32\authz.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
