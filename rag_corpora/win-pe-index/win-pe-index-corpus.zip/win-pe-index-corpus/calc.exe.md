---
name: calc.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1882 (WinBuild.160101.0800)
---
# calc.exe

**Description:** Windows Calculator
**Type:** exe
**Path:** C:\Windows\System32\calc.exe
**Version:** 10.0.26100.1882 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
