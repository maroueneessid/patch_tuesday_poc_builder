---
name: bitsperf.dll
source: pe-index
type: dll
location: system32
version: 7.8.26100.6725 (WinBuild.160101.0800)
---
# bitsperf.dll

**Description:** Perfmon Counter Access
**Type:** dll
**Path:** C:\Windows\System32\bitsperf.dll
**Version:** 7.8.26100.6725 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
