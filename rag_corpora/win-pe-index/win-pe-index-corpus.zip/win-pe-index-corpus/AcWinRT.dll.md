---
name: AcWinRT.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# AcWinRT.dll

**Description:** Windows Compatibility DLL
**Type:** dll
**Path:** C:\Windows\System32\AcWinRT.dll
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
