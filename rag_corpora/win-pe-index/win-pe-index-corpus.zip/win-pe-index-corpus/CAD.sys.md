---
name: CAD.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# CAD.sys

**Description:** Charge Arbiration Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\CAD.sys
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
