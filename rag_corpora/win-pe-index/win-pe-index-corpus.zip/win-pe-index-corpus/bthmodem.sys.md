---
name: bthmodem.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.5074 (WinBuild.160101.0800)
---
# bthmodem.sys

**Description:** Bluetooth Communications Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\bthmodem.sys
**Version:** 10.0.26100.5074 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
