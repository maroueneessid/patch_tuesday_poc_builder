---
name: cmlua.dll
source: pe-index
type: dll
location: system32
version: 7.2.26100.1 (WinBuild.160101.0800)
---
# cmlua.dll

**Description:** Connection Manager Admin API Helper
**Type:** dll
**Path:** C:\Windows\System32\cmlua.dll
**Version:** 7.2.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft(R) Connection Manager
