---
name: amdihk64.dll
source: pe-index
type: dll
location: system32
version: 2,00,00,1788
---
# amdihk64.dll

**Description:** Radeon Settings: Host Service
**Type:** dll
**Path:** C:\Windows\System32\amdihk64.dll
**Version:** 2,00,00,1788
**Product:** Radeon Settings
