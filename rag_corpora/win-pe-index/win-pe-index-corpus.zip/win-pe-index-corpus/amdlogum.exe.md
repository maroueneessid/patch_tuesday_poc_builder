---
name: amdlogum.exe
source: pe-index
type: exe
location: system32
version: 
---
# amdlogum.exe

**Description:** No description available
**Type:** exe
**Path:** C:\Windows\System32\amdlogum.exe
**Version:** 
**Product:** 
