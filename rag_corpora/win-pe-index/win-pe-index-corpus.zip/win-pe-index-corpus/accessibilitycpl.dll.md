---
name: accessibilitycpl.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.6725 (WinBuild.160101.0800)
---
# accessibilitycpl.dll

**Description:** Ease of access  control panel
**Type:** dll
**Path:** C:\Windows\System32\accessibilitycpl.dll
**Version:** 10.0.26100.6725 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
