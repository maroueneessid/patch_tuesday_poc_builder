---
name: browserexport.exe
source: pe-index
type: exe
location: system32
version: 11.00.26100.7309 (WinBuild.160101.0800)
---
# browserexport.exe

**Description:** Microsoft Edge Browser Exporter
**Type:** exe
**Path:** C:\Windows\System32\browserexport.exe
**Version:** 11.00.26100.7309 (WinBuild.160101.0800)
**Product:** Internet Explorer
