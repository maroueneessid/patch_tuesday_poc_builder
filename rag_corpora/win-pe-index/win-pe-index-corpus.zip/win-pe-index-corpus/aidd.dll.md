---
name: aidd.dll
source: pe-index
type: dll
location: system32
version: 
---
# aidd.dll

**Description:** No description available
**Type:** dll
**Path:** C:\Windows\System32\aidd.dll
**Version:** 
**Product:** 
