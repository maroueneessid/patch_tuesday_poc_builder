---
name: cmdial32.dll
source: pe-index
type: dll
location: system32
version: 7.2.26100.1 (WinBuild.160101.0800)
---
# cmdial32.dll

**Description:** Microsoft Connection Manager
**Type:** dll
**Path:** C:\Windows\System32\cmdial32.dll
**Version:** 7.2.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft(R) Connection Manager
