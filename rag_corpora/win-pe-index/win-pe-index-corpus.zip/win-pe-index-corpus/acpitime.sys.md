---
name: acpitime.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# acpitime.sys

**Description:** ACPI Wake Alarm
**Type:** driver
**Path:** C:\Windows\System32\drivers\acpitime.sys
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
