---
name: AppXDeploymentClient.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7019 (WinBuild.160101.0800)
---
# AppXDeploymentClient.dll

**Description:** AppX Deployment Client DLL
**Type:** dll
**Path:** C:\Windows\System32\AppXDeploymentClient.dll
**Version:** 10.0.26100.7019 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
