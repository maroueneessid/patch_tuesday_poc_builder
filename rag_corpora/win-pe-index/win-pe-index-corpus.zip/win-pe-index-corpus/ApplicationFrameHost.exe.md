---
name: ApplicationFrameHost.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.7309 (WinBuild.160101.0800)
---
# ApplicationFrameHost.exe

**Description:** Application Frame Host
**Type:** exe
**Path:** C:\Windows\System32\ApplicationFrameHost.exe
**Version:** 10.0.26100.7309 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
