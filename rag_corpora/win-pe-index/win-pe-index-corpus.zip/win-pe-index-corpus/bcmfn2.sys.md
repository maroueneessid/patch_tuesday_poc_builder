---
name: bcmfn2.sys
source: pe-index
type: driver
location: drivers
version: 6.3.9600.17336
---
# bcmfn2.sys

**Description:** BCM Function 2  Device Driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\bcmfn2.sys
**Version:** 6.3.9600.17336
**Product:** Windows (R) Win 7 DDK driver
