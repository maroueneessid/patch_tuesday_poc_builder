---
name: choice.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# choice.exe

**Description:** Offers the user a choice
**Type:** exe
**Path:** C:\Windows\System32\choice.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
