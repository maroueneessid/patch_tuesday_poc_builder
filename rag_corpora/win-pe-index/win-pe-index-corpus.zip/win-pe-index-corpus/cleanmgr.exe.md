---
name: cleanmgr.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# cleanmgr.exe

**Description:** Disk Space Cleanup Manager for Windows
**Type:** exe
**Path:** C:\Windows\System32\cleanmgr.exe
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
