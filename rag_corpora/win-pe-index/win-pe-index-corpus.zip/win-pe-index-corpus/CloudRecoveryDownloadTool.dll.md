---
name: CloudRecoveryDownloadTool.dll
source: pe-index
type: dll
location: system32
version: 0.2.708.0
---
# CloudRecoveryDownloadTool.dll

**Description:** Microsoft Cloud Recovery Download Tool
**Type:** dll
**Path:** C:\Windows\System32\CloudRecoveryDownloadTool.dll
**Version:** 0.2.708.0
**Product:** Microsoft Cloud Recovery Download Tool
