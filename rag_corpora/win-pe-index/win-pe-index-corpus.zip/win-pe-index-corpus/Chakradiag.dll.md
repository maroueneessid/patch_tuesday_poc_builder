---
name: Chakradiag.dll
source: pe-index
type: dll
location: system32
version: 11.00.26100.7920 (WinBuild.160101.0800)
---
# Chakradiag.dll

**Description:** Microsoft ® Chakra Diagnostics (Private)
**Type:** dll
**Path:** C:\Windows\System32\Chakradiag.dll
**Version:** 11.00.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft ® Chakra
