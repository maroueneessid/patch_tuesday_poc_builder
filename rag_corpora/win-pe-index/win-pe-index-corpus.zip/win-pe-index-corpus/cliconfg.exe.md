---
name: cliconfg.exe
source: pe-index
type: exe
location: system32
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# cliconfg.exe

**Description:** SQL Client Configuration Utility EXE
**Type:** exe
**Path:** C:\Windows\System32\cliconfg.exe
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
