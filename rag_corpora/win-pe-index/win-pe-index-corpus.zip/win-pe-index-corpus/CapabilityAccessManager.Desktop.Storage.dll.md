---
name: CapabilityAccessManager.Desktop.Storage.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.7920 (WinBuild.160101.0800)
---
# CapabilityAccessManager.Desktop.Storage.dll

**Description:** CapabilityAccessManager.Desktop.Storage
**Type:** dll
**Path:** C:\Windows\System32\CapabilityAccessManager.Desktop.Storage.dll
**Version:** 10.0.26100.7920 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
