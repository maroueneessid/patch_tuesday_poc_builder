---
name: audioresourceregistrar.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.8036 (WinBuild.160101.0800)
---
# audioresourceregistrar.dll

**Description:** AudioResourceRegistrar DLL
**Type:** dll
**Path:** C:\Windows\System32\audioresourceregistrar.dll
**Version:** 10.0.26100.8036 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
