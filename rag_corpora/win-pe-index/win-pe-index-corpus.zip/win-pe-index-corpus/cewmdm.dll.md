---
name: cewmdm.dll
source: pe-index
type: dll
location: system32
version: 12.0.26100.1
---
# cewmdm.dll

**Description:** Windows CE WMDM Service Provider
**Type:** dll
**Path:** C:\Windows\System32\cewmdm.dll
**Version:** 12.0.26100.1
**Product:** Windows Media Device Manager
