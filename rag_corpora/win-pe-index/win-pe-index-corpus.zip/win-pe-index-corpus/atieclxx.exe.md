---
name: atieclxx.exe
source: pe-index
type: exe
location: system32
version: 6.14.11.1290
---
# atieclxx.exe

**Description:** AMD External Events Client Module
**Type:** exe
**Path:** C:\Windows\System32\atieclxx.exe
**Version:** 6.14.11.1290
**Product:** AMD External Events
