---
name: basecsp.dll
source: pe-index
type: dll
location: system32
version: 10.0.26100.3323 (WinBuild.160101.0800)
---
# basecsp.dll

**Description:** Microsoft Base Smart Card Crypto Provider
**Type:** dll
**Path:** C:\Windows\System32\basecsp.dll
**Version:** 10.0.26100.3323 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
