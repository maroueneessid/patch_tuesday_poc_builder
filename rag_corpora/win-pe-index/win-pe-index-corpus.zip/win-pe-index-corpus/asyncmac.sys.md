---
name: asyncmac.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1150 (WinBuild.160101.0800)
---
# asyncmac.sys

**Description:** MS Remote Access serial network driver
**Type:** driver
**Path:** C:\Windows\System32\drivers\asyncmac.sys
**Version:** 10.0.26100.1150 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
