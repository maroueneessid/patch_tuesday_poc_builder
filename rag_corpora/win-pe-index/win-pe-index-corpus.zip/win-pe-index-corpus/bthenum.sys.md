---
name: bthenum.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.1 (WinBuild.160101.0800)
---
# bthenum.sys

**Description:** Bluetooth Bus Extender
**Type:** driver
**Path:** C:\Windows\System32\drivers\bthenum.sys
**Version:** 10.0.26100.1 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
