---
name: CEA.sys
source: pe-index
type: driver
location: drivers
version: 10.0.26100.7705 (WinBuild.160101.0800)
---
# CEA.sys

**Description:** Event Aggregation Kernel Mode Library
**Type:** driver
**Path:** C:\Windows\System32\drivers\CEA.sys
**Version:** 10.0.26100.7705 (WinBuild.160101.0800)
**Product:** Microsoft® Windows® Operating System
