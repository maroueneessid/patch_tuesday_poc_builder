---
name: amdlvr64.dll
source: pe-index
type: dll
location: system32
version: 
---
# amdlvr64.dll

**Description:** No description available
**Type:** dll
**Path:** C:\Windows\System32\amdlvr64.dll
**Version:** 
**Product:** 
