# Windows x64 Kernel Internals — Prerequisite Knowledge for Struct Resolution

> Target: Windows 11 24H2 (build 26100.x, Germanium) — x64 only.
> Purpose: Foundational mappings and pointer chains required to correctly resolve kernel structure offset queries.
> This document supplements raw struct definitions from Vergilius/ntdoc/WDK.

---

## 1. Segment Register Base Mappings (x64)

### 1.1 Kernel Mode (Ring 0)

In kernel mode on x64 Windows:

- **GS base** → `_KPCR` (Kernel Processor Control Region), per-processor.
- **FS base** → unused / zero on x64 kernel mode. Legacy x86 kernel used FS for KPCR.

The GS base is set via `MSR_GS_BASE` (MSR 0xC0000101) or `MSR_KERNEL_GS_BASE` (MSR 0xC0000102) and swapped on kernel entry via `SWAPGS`.

**Key rule:** Any disassembly showing `gs:[offset]` inside a kernel-mode function (ntoskrnl, drivers, etc.) is accessing `_KPCR + offset`. Never `_TEB`.

### 1.2 User Mode (Ring 3)

In user mode on x64 Windows:

- **GS base** → `_TEB` (Thread Environment Block), per-thread.
- **FS base** → unused on x64 user mode. Legacy x86 user mode used FS for TEB.

**Key rule:** Any disassembly showing `gs:[offset]` inside a user-mode function (ntdll, win32u, application code) is accessing `_TEB + offset`. Never `_KPCR`.

### 1.3 SWAPGS Boundary

The `SWAPGS` instruction swaps the values of `MSR_GS_BASE` and `MSR_KERNEL_GS_BASE`. This happens at:
- **Kernel entry** (syscall, interrupt, exception): SWAPGS switches GS from _TEB to _KPCR.
- **Kernel exit** (sysret, iretq): SWAPGS switches GS from _KPCR back to _TEB.

If analyzing code at the syscall entry point itself (e.g., `KiSystemCall64`), be aware that GS base changes mid-function after the SWAPGS instruction. Code before SWAPGS uses user-mode GS (_TEB); code after uses kernel-mode GS (_KPCR).

### 1.4 Disambiguation Checklist

When encountering `gs:[offset]` in disassembly:
1. **Is the function in ntoskrnl.exe, a .sys driver, or kernel-mode code?** → GS = `_KPCR`
2. **Is the function in ntdll.dll, user32.dll, application code?** → GS = `_TEB`
3. **Is it inside KiSystemCall64/KiSystemCall64Shadow before SWAPGS?** → GS = `_TEB` (still user context)
4. **Is it inside KiSystemCall64/KiSystemCall64Shadow after SWAPGS?** → GS = `_KPCR`

---

## 2. _KPCR Layout and Key Offsets (x64, 24H2)

The `_KPCR` (Kernel Processor Control Region) is a per-processor structure. On x64, it contains an embedded `_KPRCB` at a fixed offset.

### 2.1 _KPCR Top-Level Layout

| Offset | Field | Type | Notes |
|--------|-------|------|-------|
| 0x000 | GdtBase | _KGDTENTRY64* | Base of GDT for this processor |
| 0x008 | TssBase | _KTSS64* | Base of TSS for this processor |
| 0x010 | UserRsp | ULONGLONG | Saved user RSP on syscall entry |
| 0x018 | Self | _KPCR* | Self-referential pointer |
| 0x020 | CurrentPrcb | _KPRCB* | Pointer to embedded KPRCB (= &PrcbData) |
| 0x028 | LockArray | _KSPIN_LOCK_QUEUE* | |
| 0x030 | Used_Self | VOID* | |
| 0x038 | IdtBase | _KIDTENTRY64* | Base of IDT for this processor |
| 0x040-0x050 | Unused[2] | ULONGLONG | |
| 0x058 | Irql | UCHAR | Current IRQL |
| 0x059 | SecondLevelCacheAssociativity | UCHAR | |
| 0x05A | ObsoleteNumber | UCHAR | |
| 0x05B | Fill0 | UCHAR | |
| 0x05C | Unused0[3] | ULONG | |
| 0x068 | MajorVersion | USHORT | |
| 0x06A | MinorVersion | USHORT | |
| 0x06C | StallScaleFactor | ULONG | |
| 0x070-0x170 | Various | ... | Interrupt/cache fields |
| **0x180** | **PrcbData** | **_KPRCB (embedded)** | **Embedded KPRCB starts here** |

### 2.2 Critical: _KPCR to _KPRCB Transition

`_KPRCB` is **embedded** inside `_KPCR` at offset 0x180. It is NOT a pointer — it's an inline struct. This means:

- `gs:[0x180]` = first byte of the embedded `_KPRCB`
- `gs:[0x180 + KPRCB_field_offset]` = accessing a KPRCB field directly

Since _KPRCB is huge (~0xBF00 bytes on 24H2), most of the _KPCR's total size is the embedded KPRCB.

### 2.3 Accessing _KPRCB Fields via GS

Because KPRCB is embedded at KPCR+0x180, any `gs:[X]` where X >= 0x180 is a KPRCB field access. The KPRCB field offset is `X - 0x180`.

**Common pattern in disassembly:**
```
mov rax, gs:[0x188]    ; KPCR + 0x188 = KPRCB + 0x8 = KPRCB.CurrentThread
```

This is the single most common gs: access in kernel code.

---

## 3. _KPRCB Key Offsets (x64, 24H2)

The `_KPRCB` (Kernel Processor Control Block) is the primary per-processor management structure. It is embedded inside `_KPCR` at offset 0x180.

### 3.1 Head Fields (Most Frequently Accessed)

| KPRCB Offset | GS Offset | Field | Type | Notes |
|-------------|-----------|-------|------|-------|
| 0x000 | 0x180 | MxCsr | ULONG | MXCSR register value |
| 0x004 | 0x184 | LegacyNumber | UCHAR | Legacy processor number |
| 0x005 | 0x185 | ReservedMustBeZero | UCHAR | |
| 0x006 | 0x186 | InterruptRequest | UCHAR | |
| 0x007 | 0x187 | IdleHalt | UCHAR | |
| **0x008** | **0x188** | **CurrentThread** | **_KTHREAD*** | **Pointer to currently executing thread** |
| **0x010** | **0x190** | **NextThread** | **_KTHREAD*** | **Next thread scheduled (may be NULL)** |
| **0x018** | **0x198** | **IdleThread** | **_KTHREAD*** | **Idle thread for this processor** |
| 0x020 | 0x1A0 | NestingLevel | UCHAR | |
| 0x021 | 0x1A1 | ClockOwner | UCHAR | |
| 0x022 | 0x1A2 | PendingTickFlags | UCHAR | |
| 0x023 | 0x1A3 | IdleState | UCHAR | |
| 0x024 | 0x1A4 | Number | ULONG | Processor number |
| 0x028 | 0x1A8 | RspBase | ULONGLONG | Kernel stack RSP base |
| 0x030 | 0x1B0 | PrcbLock | ULONGLONG | |
| 0x038 | 0x1B8 | PriorityState | _KPRIORITY_STATE* | Scheduler priority state |

### 3.2 Common GS Access Patterns in Disassembly

| Disassembly Pattern | Resolves To | Usage |
|---------------------|-------------|-------|
| `mov rax, gs:[0x188]` | KPRCB.CurrentThread (_KTHREAD*) | Get current thread |
| `mov rax, gs:[0x190]` | KPRCB.NextThread (_KTHREAD*) | Get next scheduled thread (can be NULL) |
| `mov rax, gs:[0x198]` | KPRCB.IdleThread (_KTHREAD*) | Get idle thread |
| `movzx eax, byte ptr gs:[0x1A4]` / `mov eax, gs:[0x1A4]` | KPRCB.Number | Get current processor number |
| `mov rax, gs:[0x1A8]` | KPRCB.RspBase | Get kernel stack base |
| `mov rax, gs:[0x18]` | KPCR.Self (_KPCR*) | Self-referential KPCR pointer |
| `movzx eax, byte ptr gs:[0x58]` | KPCR.Irql | Read current IRQL (sometimes inlined KeGetCurrentIrql) |

### 3.3 NextThread NULL Warning

`KPRCB.NextThread` at gs:[0x190] is frequently NULL. It only contains a valid pointer when the scheduler has preselected a thread to run next. Any code that dereferences `gs:[0x190]` without a NULL check first is either:
- Inside scheduler code that guarantees a next thread exists
- A bug

---

## 4. _KTHREAD / _ETHREAD Relationship

### 4.1 Embedded Struct Pattern

`_ETHREAD` (Executive Thread) contains `_KTHREAD` (Kernel Thread) as its **first member**, embedded at offset 0x0:

```
struct _ETHREAD {                   // sizeof = 0x900 (24H2)
    struct _KTHREAD Tcb;            // offset 0x0, sizeof = 0x480 (24H2)
    union _LARGE_INTEGER CreateTime; // offset 0x480
    ...                             // remaining ETHREAD-specific fields
};
```

**Consequences:**
- A `_KTHREAD*` and an `_ETHREAD*` to the same thread object have the **same numerical address**.
- `_KTHREAD*` IS `_ETHREAD*` — they point to the same memory. The kernel casts freely between them.
- Any offset < 0x480 from CurrentThread is a `_KTHREAD` field.
- Any offset >= 0x480 from CurrentThread is an `_ETHREAD`-specific field (past the embedded Tcb).
- `gs:[0x188]` returns what is typed as `_KTHREAD*` but the full allocation is always an `_ETHREAD`.

### 4.2 Sizeof Values (24H2)

- `sizeof(_KTHREAD)` = **0x480** bytes
- `sizeof(_ETHREAD)` = **0x900** bytes
- _ETHREAD-specific region: offsets 0x480 through 0x8FF

### 4.3 Resolution Rule for CurrentThread + Offset

When you see code like:
```
mov rax, gs:[0x188]     ; rax = _KTHREAD* (== _ETHREAD*)
mov rbx, [rax + 0xNN]   ; access field at offset 0xNN
```

Apply this rule:
- If `0xNN < 0x480` → look up in `_KTHREAD` struct definition
- If `0x480 <= 0xNN < 0x900` → look up in `_ETHREAD` struct definition
- If `0xNN >= 0x900` → **out of bounds**, invalid access or wrong struct identification

---

## 5. _KPROCESS / _EPROCESS Relationship

### 5.1 Embedded Struct Pattern (Same as KTHREAD/ETHREAD)

`_EPROCESS` contains `_KPROCESS` as its first member at offset 0x0:

```
struct _EPROCESS {                  // sizeof ~ 0xA00+ (24H2, varies)
    struct _KPROCESS Pcb;           // offset 0x0, sizeof = 0x438 (24H2)
    struct _EX_PUSH_LOCK ProcessLock; // offset 0x438
    ...
};
```

- A `_KPROCESS*` and `_EPROCESS*` to the same process have the **same address**.
- Offsets < 0x438 are _KPROCESS fields; offsets >= 0x438 are _EPROCESS-specific.

### 5.2 Getting _EPROCESS from _ETHREAD

Most common pointer chain:
```
gs:[0x188]                          → _KTHREAD* (CurrentThread)
_KTHREAD + 0x98                     → _KAPC_STATE (embedded ApcState)
_KAPC_STATE + 0x20                  → _KPROCESS* Process (== _EPROCESS*)
```

Or equivalently as a single offset:
```
gs:[0x188] → deref → +0xB8         → _KPROCESS* (0x98 + 0x20 = 0xB8)
```

This is the **canonical way** kernel code gets the current process from the current thread. It goes through `ApcState.Process`, NOT through `_KTHREAD.Process` (which is at a different offset and represents the thread's original process, not the currently-attached process).

### 5.3 _KTHREAD.ApcState vs _KTHREAD.Process

| Field | Offset (24H2) | Type | Meaning |
|-------|---------------|------|---------|
| _KTHREAD.ApcState | 0x98 | _KAPC_STATE (embedded) | Current APC state including attached process |
| _KTHREAD.ApcState.Process | 0x98 + 0x20 = 0xB8 | _KPROCESS* | **Currently attached** process (follows KeAttachProcess/KeStackAttachProcess) |
| _KTHREAD.Process | ~0x220 (build-dependent) | _KPROCESS* | **Original/owner** process (does NOT change on attach) |

When a thread calls `KeStackAttachProcess` to attach to another process's address space:
- `ApcState.Process` changes to the target process
- `_KTHREAD.Process` stays as the original process

Most kernel code uses `ApcState.Process` (offset 0xB8 from KTHREAD) to get "the current process." `PsGetCurrentProcess()` internally uses this path.

---

## 6. _KAPC_STATE Layout (Embedded in _KTHREAD at 0x98)

The `_KAPC_STATE` structure tracks APC (Asynchronous Procedure Call) queues and the process context for a thread.

### 6.1 Field Layout

| Offset within _KAPC_STATE | Offset within _KTHREAD | Field | Type |
|---------------------------|----------------------|-------|------|
| 0x00 | 0x98 | ApcListHead[0] | LIST_ENTRY | Kernel-mode APC list |
| 0x10 | 0xA8 | ApcListHead[1] | LIST_ENTRY | User-mode APC list |
| 0x20 | 0xB8 | Process | _KPROCESS* | Currently attached process |
| 0x28 | 0xC0 | InProgressFlags | union (UCHAR + bitfield) | |
| 0x29 | 0xC1 | KernelApcPending | UCHAR | |
| 0x2A | 0xC2 | UserApcPendingAll | UCHAR | |

### 6.2 _KAPC_STATE is Embedded, Not a Pointer

`_KTHREAD.ApcState` is an **embedded struct**, not a pointer. When disassembly shows:
```
mov rax, gs:[0x188]     ; rax = _KTHREAD*
mov rbx, [rax + 0xB8]   ; rbx = _KTHREAD.ApcState.Process
```

This is a single dereference — `rax + 0xB8` accesses memory directly within the KTHREAD allocation, NOT through a pointer indirection. The decompiler may show this as `thread->ApcState.Process` which looks like two dereferences but is actually one (struct member access + pointer read).

If you see a double dereference pattern like:
```
mov rax, [rcx + 0x98]   ; load pointer from offset 0x98
mov rbx, [rax + 0x20]   ; dereference that pointer + 0x20
```

This would be WRONG for ApcState (it's embedded, not a pointer). If you encounter this pattern in a decompiler output, the decompiler is mistyping the field — ApcState is inline, not a pointer.

---

## 7. _TEB Key Offsets (User Mode, for Disambiguation)

When the question is about **user-mode** `gs:` accesses, these are the relevant _TEB fields.

### 7.1 Commonly Accessed _TEB Fields

| Offset | Field | Type | Notes |
|--------|-------|------|-------|
| 0x000 | NtTib.ExceptionList | _EXCEPTION_REGISTRATION_RECORD* | SEH chain (rarely used on x64) |
| 0x008 | NtTib.StackBase | VOID* | |
| 0x010 | NtTib.StackLimit | VOID* | |
| 0x030 | NtTib.Self | _TEB* | Self-referential pointer |
| 0x048 | ClientId.UniqueProcess | HANDLE | Current PID |
| 0x050 | ClientId.UniqueThread | HANDLE | Current TID |
| 0x060 | ProcessEnvironmentBlock | _PEB* | Pointer to PEB |
| 0x068 | LastErrorValue | ULONG | GetLastError() value |
| 0x1740 | FlsData | VOID* | Fiber-local storage pointer |

### 7.2 Distinguishing Kernel GS from User GS

If offset < 0x180 and the function is ambiguous:
- Check if the accessed field makes sense as _KPCR (kernel) or _TEB (user)
- _KPCR has IDT/GDT/TSS pointers at low offsets — these are kernel-only concepts
- _TEB has stack base/limit, PEB pointer — these are user-only concepts
- If offset >= 0x180 it's almost certainly _KPRCB (kernel) because _TEB doesn't have meaningful fields that far out that look like what kernel code would access

---

## 8. PEB Key Offsets (User Mode, for Disambiguation)

The `_PEB` is accessed via `_TEB.ProcessEnvironmentBlock` at `gs:[0x60]` in user mode.

### 8.1 Common _PEB Fields

| Offset | Field | Type | Notes |
|--------|-------|------|-------|
| 0x000 | InheritedAddressSpace | BOOLEAN | |
| 0x002 | BeingDebugged | UCHAR | Anti-debug check target |
| 0x008 | Mutant | VOID* | |
| 0x010 | ImageBaseAddress | VOID* | Base address of main executable |
| 0x018 | Ldr | _PEB_LDR_DATA* | Loaded module list |
| 0x020 | ProcessParameters | _RTL_USER_PROCESS_PARAMETERS* | Command line, environment, etc. |
| 0x0BC | NumberOfProcessors | ULONG | Processor count |
| 0x0E8 | NumberOfHeaps | ULONG | |
| 0x0F0 | ProcessHeaps | VOID** | Array of heap handles |

### 8.2 Common Confusion: PEB.NumberOfProcessors

`_PEB.NumberOfProcessors` is at offset **0x0BC** in the PEB, NOT at 0xB8. This is a common source of off-by-one errors when manually resolving struct offsets. The PEB is a user-mode structure accessed via `gs:[0x60]` (TEB.ProcessEnvironmentBlock) — it has nothing to do with kernel-mode GS accesses.

---

## 9. Common Kernel Pointer Chains

### 9.1 Get Current Thread (_KTHREAD* / _ETHREAD*)

```
gs:[0x188] → _KTHREAD* CurrentThread
```
Single memory read. This is PsGetCurrentThread() inlined.

### 9.2 Get Current Process (_KPROCESS* / _EPROCESS*)

```
gs:[0x188] → deref → _KTHREAD*
_KTHREAD + 0xB8 → _KPROCESS* (via ApcState.Process)
```
Two memory reads. This is PsGetCurrentProcess() inlined. Returns the **attached** process.

### 9.3 Get Current Process ID

```
gs:[0x188] → deref → _ETHREAD*
_ETHREAD + 0x4C8 → _CLIENT_ID Cid
_CLIENT_ID + 0x00 → UniqueProcess (HANDLE, used as PID)
_CLIENT_ID + 0x08 → UniqueThread (HANDLE, used as TID)
```
So: CurrentThread + 0x4C8 = PID, CurrentThread + 0x4D0 = TID.

### 9.4 Get Current Process Token

```
gs:[0x188] → _KTHREAD*
+ 0xB8 → _KPROCESS* (== _EPROCESS*)
_EPROCESS + 0x248 → Token (_EX_FAST_REF)
```
Token stealing exploits read/write this chain. The _EX_FAST_REF needs masking: `Token.Value & ~0xF` gives the actual _TOKEN* address.

### 9.5 Get Current Process Image File Name

```
gs:[0x188] → _KTHREAD*
+ 0xB8 → _EPROCESS*
_EPROCESS + 0x5B8 → ImageFileName (CHAR[15])
```
Note: ImageFileName is a fixed 15-byte char array, NOT a UNICODE_STRING. It's truncated. For the full image name, use SeLocateProcessImageName or similar.

### 9.6 Get Current Processor Number

```
gs:[0x1A4] → ULONG (KPRCB.Number at KPRCB+0x24, KPCR+0x180+0x24)
```
Single read, no dereference. This is KeGetCurrentProcessorNumberEx() inlined (simplified).

### 9.7 Get Current IRQL

```
gs:[0x58] → UCHAR (KPCR.Irql)
```
Single byte read. This is KeGetCurrentIrql() inlined on some builds.

---

## 10. Embedded vs Pointer: Recognition Patterns

### 10.1 Rule

An **embedded** struct means the child struct's bytes are inline within the parent. Accessing a field in the child requires ONE dereference (the parent pointer), not two.

A **pointed-to** struct means the parent contains a pointer to the child. Accessing a field in the child requires TWO dereferences (parent pointer → child pointer → field).

### 10.2 Key Embedded Structs in Kernel Objects

| Parent | Field | Child (Embedded) | Parent Offset |
|--------|-------|-------------------|--------------|
| _KPCR | PrcbData | _KPRCB | 0x180 |
| _ETHREAD | Tcb | _KTHREAD | 0x0 |
| _EPROCESS | Pcb | _KPROCESS | 0x0 |
| _KTHREAD | ApcState | _KAPC_STATE | 0x98 |
| _KTHREAD | SavedApcState | _KAPC_STATE | build-dependent |
| _KTHREAD | WaitBlock[4] | _KWAIT_BLOCK | build-dependent |
| _KTHREAD | Header | _DISPATCHER_HEADER | 0x0 |
| _KPROCESS | Header | _DISPATCHER_HEADER | 0x0 |
| _KPROCESS | ProfileListHead | _LIST_ENTRY | build-dependent |

### 10.3 Key Pointed-To Structs (Require Double Dereference)

| Parent | Field | Child (Pointed-To) | Notes |
|--------|-------|---------------------|-------|
| _KTHREAD | ApcState.Process | _KPROCESS* | Pointer inside embedded _KAPC_STATE |
| _KTHREAD | Process | _KPROCESS* | Direct pointer to owning process |
| _KTHREAD | StackBase / StackLimit | VOID* | Stack boundary pointers |
| _KPRCB | CurrentThread | _KTHREAD* | Pointer, not embedded |
| _EPROCESS | Token | _EX_FAST_REF | Encoded pointer (mask low 4 bits) |
| _TEB | ProcessEnvironmentBlock | _PEB* | User-mode only |

### 10.4 Decompiler Pitfall

Decompilers (Ghidra, IDA) may show embedded struct access as:
```c
thread->ApcState.Process
```
This looks like `thread` → pointer deref → `ApcState` → pointer deref → `Process`, but it's actually:
```
[thread_ptr + 0x98 + 0x20]  =  [thread_ptr + 0xB8]
```
One dereference total. The dot notation is struct member access (compile-time offset calculation), not a runtime pointer chase.

---

## 11. _EX_FAST_REF Decoding

Several kernel fields use `_EX_FAST_REF` to store encoded pointers. The low bits store a reference count, not part of the address.

### 11.1 Structure

```
union _EX_FAST_REF {
    VOID* Object;           // full value
    ULONGLONG RefCnt : 4;   // low 4 bits = reference count
    ULONGLONG Value;         // raw 64-bit value
};
```

### 11.2 Decoding

To get the actual pointer: `Value & ~0xF` (mask off low 4 bits).

### 11.3 Fields Using _EX_FAST_REF

| Struct | Field | Contains Pointer To |
|--------|-------|---------------------|
| _EPROCESS | Token (offset 0x248 on 24H2) | _TOKEN* |
| _EPROCESS | UniqueProcessId is NOT _EX_FAST_REF | — |

---

## 12. _OBJECT_HEADER Relationship

Every kernel object (process, thread, file, etc.) is preceded in memory by an `_OBJECT_HEADER`. The object body (e.g., _EPROCESS) starts immediately after the header.

### 12.1 Getting Object Header from Object Body

```c
_OBJECT_HEADER* header = CONTAINING_RECORD(object, _OBJECT_HEADER, Body);
// Equivalent to: (UCHAR*)object - offsetof(_OBJECT_HEADER, Body)
// Body offset within _OBJECT_HEADER = 0x30 on 24H2
```

So: `ObjectHeader = ObjectBody - 0x30`

### 12.2 Key _OBJECT_HEADER Fields (24H2)

| Offset | Field | Type | Notes |
|--------|-------|------|-------|
| 0x00 | PointerCount | LONGLONG | Reference count |
| 0x08 | HandleCount / NextToFree | union | |
| 0x10 | Lock | EX_PUSH_LOCK | |
| 0x18 | TypeIndex | UCHAR | Encoded type index (XOR'd with cookie) |
| 0x1A | InfoMask | UCHAR | Bitmask of optional headers present |
| 0x1C | Flags | UCHAR | |
| 0x20 | ObjectCreateInfo / QuotaBlockCharged | union | |
| 0x28 | SecurityDescriptor | VOID* | |
| 0x30 | Body | start of object body | _EPROCESS, _ETHREAD, _FILE_OBJECT, etc. |

### 12.3 TypeIndex Decoding (10+)

Since Windows 10, TypeIndex is XOR-encoded:
```
ActualTypeIndex = ObHeaderCookie ^ TypeIndex ^ (UCHAR)((ULONG_PTR)ObjectHeader >> 8)
```
This prevents trivial type confusion in pool corruption exploits.

---

## 13. LIST_ENTRY Traversal and CONTAINING_RECORD

### 13.1 _LIST_ENTRY Structure

```c
struct _LIST_ENTRY {
    _LIST_ENTRY* Flink;  // offset 0x00 — forward link
    _LIST_ENTRY* Blink;  // offset 0x08 — backward link
};
```

### 13.2 CONTAINING_RECORD Macro

Given a pointer to a LIST_ENTRY member within a struct, get back the struct base:
```c
#define CONTAINING_RECORD(address, type, field) \
    ((type*)((UCHAR*)(address) - offsetof(type, field)))
```

### 13.3 Common List Traversal in Kernel

When disassembly reads a LIST_ENTRY.Flink then subtracts a constant, it's doing CONTAINING_RECORD:
```asm
mov rax, [rcx]          ; Flink
sub rax, 0x538          ; CONTAINING_RECORD offset
```
This means the LIST_ENTRY is at offset 0x538 within the target struct. For _ETHREAD, offset 0x538 = ThreadListEntry.

### 13.4 Key LIST_ENTRY Fields in Common Structs

| Struct | Field | Offset (24H2) | Links To |
|--------|-------|---------------|----------|
| _EPROCESS | ActiveProcessLinks | 0x1F0 (approx) | Other _EPROCESS objects |
| _ETHREAD | ThreadListEntry | 0x538 | Threads in same process |
| _ETHREAD | IrpList | 0x500 | IRPs pending on this thread |
| _ETHREAD | ActiveTimerListHead | 0x4B8 | Active timers for this thread |

---

## 14. Version Sensitivity Notes

### 14.1 Offsets That Are Relatively Stable Across Builds

These offsets rarely change between Windows 10/11 versions:
- gs:[0x188] → CurrentThread (KPRCB+0x8)
- _KTHREAD+0x0 → Header (DISPATCHER_HEADER)
- _KTHREAD+0x98 → ApcState
- _ETHREAD+0x0 → Tcb (_KTHREAD, embedded)
- _EPROCESS+0x0 → Pcb (_KPROCESS, embedded)

### 14.2 Offsets That Frequently Shift Between Builds

These offsets change regularly and MUST be verified against the target build's PDB:
- _EPROCESS.Token
- _EPROCESS.ImageFileName
- _EPROCESS.ActiveProcessLinks
- _EPROCESS.UniqueProcessId
- _ETHREAD.Cid
- _KTHREAD.Process (the direct pointer, not ApcState.Process)
- sizeof(_KTHREAD) and sizeof(_ETHREAD)
- Most _EPROCESS fields beyond the Pcb

### 14.3 Verification Commands (WinDbg)

Always verify offsets against the actual PDB:
```
dt nt!_KTHREAD
dt nt!_ETHREAD
dt nt!_EPROCESS
dt nt!_KPCR
dt nt!_KPRCB
dt nt!_KAPC_STATE
dt nt!_OBJECT_HEADER
dt nt!_EX_FAST_REF
```

For specific field:
```
dt nt!_EPROCESS Token.
?? #FIELD_OFFSET(nt!_EPROCESS, Token)
```

---

## 15. MSR Registers Relevant to Struct Resolution

### 15.1 Key MSRs

| MSR | Value | Purpose | Related Struct |
|-----|-------|---------|---------------|
| MSR_GS_BASE | 0xC0000101 | Current GS base | _KPCR (kernel) or _TEB (user) |
| MSR_KERNEL_GS_BASE | 0xC0000102 | Swapped GS base (inactive mode) | Whichever is not current |
| MSR_LSTAR | 0xC0000082 | SYSCALL target RIP | Points to KiSystemCall64 |
| MSR_STAR | 0xC0000081 | SYSCALL CS/SS selectors | Segment setup |
| MSR_FMASK | 0xC0000084 | SYSCALL RFLAGS mask | |

### 15.2 Reading GS Base in WinDbg

```
rdmsr 0xC0000101     ; current GS base
rdmsr 0xC0000102     ; kernel GS base (if currently in user mode) or user GS base (if in kernel)
```

---

## 16. Pool Allocation Tags for Common Objects

When analyzing pool allocations, these tags help identify which structure is at a given address:

| Tag | Structure | Pool Type |
|-----|-----------|-----------|
| Proc | _EPROCESS | NonPagedPool |
| Thre | _ETHREAD | NonPagedPool |
| File | _FILE_OBJECT | NonPagedPool |
| ObHd | _OBJECT_HEADER (+ optional headers) | NonPagedPool |
| Toke | _TOKEN | PagedPool |
| Irp  | _IRP | NonPagedPool |
| Mdl  | _MDL | NonPagedPool |

Use `!pool <address>` or `!pooltag <tag>` in WinDbg to identify allocations.
