---
name: KD_NAMESPACE_ENUM
kind: ENUM
sizeof: 4
sizeof_hex: 0x4
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# KD_NAMESPACE_ENUM

**Kind:** ENUM | **Size:** 4 bytes (0x4)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | KdNameSpacePCI | LONG |
| 1 | 0x001 | KdNameSpaceACPI | LONG |
| 2 | 0x002 | KdNameSpaceAny | LONG |
| 3 | 0x003 | KdNameSpaceNone | LONG |
| 4 | 0x004 | KdNameSpaceMax | LONG |
