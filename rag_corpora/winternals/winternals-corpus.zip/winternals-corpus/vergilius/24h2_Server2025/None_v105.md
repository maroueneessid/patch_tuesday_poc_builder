---
name: None
kind: ARRAY
sizeof: 112
sizeof_hex: 0x70
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# None

**Kind:** ARRAY | **Size:** 112 bytes (0x70)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 7 | 0x007 | element | _KCLOCK_TIMER_DEADLINE_ENTRY |
