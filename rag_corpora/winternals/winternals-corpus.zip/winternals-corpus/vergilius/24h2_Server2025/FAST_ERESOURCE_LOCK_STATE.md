---
name: FAST_ERESOURCE_LOCK_STATE
kind: UNION
sizeof: 8
sizeof_hex: 0x8
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# FAST_ERESOURCE_LOCK_STATE

**Kind:** UNION | **Size:** 8 bytes (0x8)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | Value | LONGLONG |
| 0 | 0x000 | Exclusive:1 | LONGLONG |
| 0 | 0x000 | Conflict:1 | LONGLONG |
| 0 | 0x000 | ShareCount:62 | LONGLONG |
