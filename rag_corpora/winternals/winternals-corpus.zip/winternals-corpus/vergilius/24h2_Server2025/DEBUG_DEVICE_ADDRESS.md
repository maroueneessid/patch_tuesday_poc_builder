---
name: DEBUG_DEVICE_ADDRESS
kind: STRUCT
sizeof: 24
sizeof_hex: 0x18
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# DEBUG_DEVICE_ADDRESS

**Kind:** STRUCT | **Size:** 24 bytes (0x18)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | Type | UCHAR |
| 1 | 0x001 | Valid | UCHAR |
| 2 | 0x002 | Reserved | None |
| 2 | 0x002 | BitWidth | UCHAR |
| 3 | 0x003 | AccessSize | UCHAR |
| 8 | 0x008 | TranslatedAddress | UCHAR* |
| 16 | 0x010 | Length | ULONG |
