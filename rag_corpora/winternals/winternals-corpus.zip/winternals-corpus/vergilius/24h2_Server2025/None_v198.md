---
name: None
kind: ARRAY
sizeof: 192
sizeof_hex: 0xC0
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# None

**Kind:** ARRAY | **Size:** 192 bytes (0xC0)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 24 | 0x018 | element | ULONGLONG |
