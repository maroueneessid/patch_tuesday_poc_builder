---
name: MM_BOOT_MARK
kind: ENUM
sizeof: 4
sizeof_hex: 0x4
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# MM_BOOT_MARK

**Kind:** ENUM | **Size:** 4 bytes (0x4)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | BuiltLoaderTree | LONG |
| 1 | 0x001 | AppliedMemoryLicense | LONG |
| 2 | 0x002 | RemovedLargeDescriptors | LONG |
| 3 | 0x003 | WalkedBootMappings | LONG |
| 4 | 0x004 | CreatedPfnDatabase | LONG |
| 5 | 0x005 | InitializedPfnsForValidMappings | LONG |
| 6 | 0x006 | CreateInitialPfnsForMemoryBlock | LONG |
| 7 | 0x007 | InitializedGapFrames | LONG |
| 8 | 0x008 | EmployedGapFrames | LONG |
| 9 | 0x009 | UnmappedSparseRanges | LONG |
| 10 | 0x00A | BuiltNodeStructures | LONG |
| 11 | 0x00B | CreatedPfnBitMaps | LONG |
| 12 | 0x00C | InitializedLargePageRuns | LONG |
| 13 | 0x00D | NotUsed | LONG |
| 14 | 0x00E | InitializedSpecialPurposeMemory | LONG |
| 15 | 0x00F | CreatedSlabs | LONG |
| 16 | 0x010 | InitializedDriverImages | LONG |
| 17 | 0x011 | InitializedHotPatching | LONG |
| 18 | 0x012 | InitializedRelocations | LONG |
| 19 | 0x013 | InitializedTbFlushing | LONG |
| 20 | 0x014 | MaximumBootMark | LONG |
