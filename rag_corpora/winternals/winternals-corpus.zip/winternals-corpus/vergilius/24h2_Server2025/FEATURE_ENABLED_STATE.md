---
name: FEATURE_ENABLED_STATE
kind: ENUM
sizeof: 4
sizeof_hex: 0x4
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# FEATURE_ENABLED_STATE

**Kind:** ENUM | **Size:** 4 bytes (0x4)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | FEATURE_ENABLED_STATE_DEFAULT | LONG |
| 1 | 0x001 | FEATURE_ENABLED_STATE_DISABLED | LONG |
| 2 | 0x002 | FEATURE_ENABLED_STATE_ENABLED | LONG |
| 128 | 0x080 | FEATURE_ENABLED_STATE_HAS_NOTIFICATION | LONG |
| 64 | 0x040 | FEATURE_ENABLED_STATE_IS_WEXP_CONFIGURATION | LONG |
