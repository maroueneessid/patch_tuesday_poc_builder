---
name: None
kind: ARRAY
sizeof: 0
sizeof_hex: 0x0
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# None

**Kind:** ARRAY | **Size:** 0 bytes (0x0)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | element | _SCATTER_GATHER_ELEMENT |
