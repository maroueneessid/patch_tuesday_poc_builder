---
name: None
kind: ARRAY
sizeof: 8
sizeof_hex: 0x8
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# None

**Kind:** ARRAY | **Size:** 8 bytes (0x8)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 2 | 0x002 | element | _PNP_DEVNODE_QUERY_REBALANCE_VETO_REASON |
