---
name: FEATURE_LOGGED_TRAITS
kind: STRUCT
sizeof: 6
sizeof_hex: 0x6
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
const: true
---

# const FEATURE_LOGGED_TRAITS

**Kind:** STRUCT | **Size:** 6 bytes (0x6)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | version | USHORT |
| 2 | 0x002 | baseVersion | USHORT |
| 4 | 0x004 | stage | UCHAR |
