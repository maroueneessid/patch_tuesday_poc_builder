---
name: None
kind: ARRAY
sizeof: 120
sizeof_hex: 0x78
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# None

**Kind:** ARRAY | **Size:** 120 bytes (0x78)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 15 | 0x00F | element | ULONGLONG |
