---
name: HAL_APIC_DESTINATION_MODE
kind: ENUM
sizeof: 4
sizeof_hex: 0x4
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# HAL_APIC_DESTINATION_MODE

**Kind:** ENUM | **Size:** 4 bytes (0x4)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 1 | 0x001 | ApicDestinationModePhysical | LONG |
| 2 | 0x002 | ApicDestinationModeLogicalFlat | LONG |
| 3 | 0x003 | ApicDestinationModeLogicalClustered | LONG |
| 4 | 0x004 | ApicDestinationModeUnknown | LONG |
