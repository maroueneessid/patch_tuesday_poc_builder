---
name: FEATURE_ERROR
kind: STRUCT
sizeof: 104
sizeof_hex: 0x68
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
const: true
---

# const FEATURE_ERROR

**Kind:** STRUCT | **Size:** 104 bytes (0x68)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | hr | HRESULT |
| 4 | 0x004 | lineNumber | USHORT |
| 8 | 0x008 | file | CHAR* |
| 16 | 0x010 | process | CHAR* |
| 24 | 0x018 | modulePath | CHAR* |
| 32 | 0x020 | callerReturnAddressOffset | ULONG |
| 40 | 0x028 | callerModule | CHAR* |
| 48 | 0x030 | message | CHAR* |
| 56 | 0x038 | originLineNumber | USHORT |
| 64 | 0x040 | originFile | CHAR* |
| 72 | 0x048 | originModule | CHAR* |
| 80 | 0x050 | originCallerReturnAddressOffset | ULONG |
| 88 | 0x058 | originCallerModule | CHAR* |
| 96 | 0x060 | originName | CHAR* |
