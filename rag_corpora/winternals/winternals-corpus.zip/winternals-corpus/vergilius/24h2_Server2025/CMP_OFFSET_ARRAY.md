---
name: CMP_OFFSET_ARRAY
kind: STRUCT
sizeof: 24
sizeof_hex: 0x18
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# CMP_OFFSET_ARRAY

**Kind:** STRUCT | **Size:** 24 bytes (0x18)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | FileOffset | ULONG |
| 8 | 0x008 | DataBuffer | VOID* |
| 16 | 0x010 | DataLength | ULONG |
