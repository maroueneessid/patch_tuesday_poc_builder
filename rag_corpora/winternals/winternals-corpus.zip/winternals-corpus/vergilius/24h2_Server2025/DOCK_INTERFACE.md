---
name: DOCK_INTERFACE
kind: STRUCT
sizeof: 48
sizeof_hex: 0x30
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# DOCK_INTERFACE

**Kind:** STRUCT | **Size:** 48 bytes (0x30)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | Size | USHORT |
| 2 | 0x002 | Version | USHORT |
| 8 | 0x008 | Context | VOID* |
| 16 | 0x010 | InterfaceReference | FUNCTION_PTR* |
| 24 | 0x018 | InterfaceDereference | FUNCTION_PTR* |
| 32 | 0x020 | ProfileDepartureSetMode | FUNCTION_PTR* |
| 40 | 0x028 | ProfileDepartureUpdate | FUNCTION_PTR* |
