---
name: None
kind: ARRAY
sizeof: 6144
sizeof_hex: 0x1800
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# None

**Kind:** ARRAY | **Size:** 6144 bytes (0x1800)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 256 | 0x100 | element | _WHEA_RECOVERY_CONTEXT_PAGE_INFO |
