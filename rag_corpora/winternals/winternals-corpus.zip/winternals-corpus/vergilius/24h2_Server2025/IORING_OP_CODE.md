---
name: IORING_OP_CODE
kind: ENUM
sizeof: 4
sizeof_hex: 0x4
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# IORING_OP_CODE

**Kind:** ENUM | **Size:** 4 bytes (0x4)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | IORING_OP_NOP | LONG |
| 1 | 0x001 | IORING_OP_READ | LONG |
| 2 | 0x002 | IORING_OP_REGISTER_FILES | LONG |
| 3 | 0x003 | IORING_OP_REGISTER_BUFFERS | LONG |
| 4 | 0x004 | IORING_OP_CANCEL | LONG |
| 5 | 0x005 | IORING_OP_WRITE | LONG |
| 6 | 0x006 | IORING_OP_FLUSH | LONG |
| 7 | 0x007 | IORING_OP_READ_SCATTER | LONG |
| 8 | 0x008 | IORING_OP_WRITE_GATHER | LONG |
