---
name: HAL_PRIVATE_DISPATCH
kind: STRUCT
sizeof: 1304
sizeof_hex: 0x518
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# HAL_PRIVATE_DISPATCH

**Kind:** STRUCT | **Size:** 1304 bytes (0x518)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | Version | ULONG |
| 8 | 0x008 | HalHandlerForBus | FUNCTION_PTR* |
| 16 | 0x010 | HalHandlerForConfigSpace | FUNCTION_PTR* |
| 24 | 0x018 | HalLocateHiberRanges | FUNCTION_PTR* |
| 32 | 0x020 | HalRegisterBusHandler | FUNCTION_PTR* |
| 40 | 0x028 | HalSetWakeEnable | FUNCTION_PTR* |
| 48 | 0x030 | HalSetWakeAlarm | FUNCTION_PTR* |
| 56 | 0x038 | HalPciTranslateBusAddress | FUNCTION_PTR* |
| 64 | 0x040 | HalPciAssignSlotResources | FUNCTION_PTR* |
| 72 | 0x048 | HalHaltSystem | FUNCTION_PTR* |
| 80 | 0x050 | HalFindBusAddressTranslation | FUNCTION_PTR* |
| 88 | 0x058 | HalResetDisplay | FUNCTION_PTR* |
| 96 | 0x060 | HalAllocateMapRegisters | FUNCTION_PTR* |
| 104 | 0x068 | KdSetupPciDeviceForDebugging | FUNCTION_PTR* |
| 112 | 0x070 | KdReleasePciDeviceForDebugging | FUNCTION_PTR* |
| 120 | 0x078 | KdGetAcpiTablePhase0 | FUNCTION_PTR* |
| 128 | 0x080 | KdCheckPowerButton | FUNCTION_PTR* |
| 136 | 0x088 | HalVectorToIDTEntry | FUNCTION_PTR* |
| 144 | 0x090 | KdMapPhysicalMemory64 | FUNCTION_PTR* |
| 152 | 0x098 | KdUnmapVirtualAddress | FUNCTION_PTR* |
| 160 | 0x0A0 | KdGetPciDataByOffset | FUNCTION_PTR* |
| 168 | 0x0A8 | KdSetPciDataByOffset | FUNCTION_PTR* |
| 176 | 0x0B0 | HalGetInterruptVectorOverride | FUNCTION_PTR* |
| 184 | 0x0B8 | HalGetVectorInputOverride | FUNCTION_PTR* |
| 192 | 0x0C0 | HalLoadMicrocode | FUNCTION_PTR* |
| 200 | 0x0C8 | HalUnloadMicrocode | FUNCTION_PTR* |
| 208 | 0x0D0 | HalPostMicrocodeUpdate | FUNCTION_PTR* |
| 216 | 0x0D8 | HalAllocateMessageTargetOverride | FUNCTION_PTR* |
| 224 | 0x0E0 | HalFreeMessageTargetOverride | FUNCTION_PTR* |
| 232 | 0x0E8 | HalDpReplaceBegin | FUNCTION_PTR* |
| 240 | 0x0F0 | HalDpReplaceTarget | FUNCTION_PTR* |
| 248 | 0x0F8 | HalDpReplaceControl | FUNCTION_PTR* |
| 256 | 0x100 | HalDpReplaceEnd | FUNCTION_PTR* |
| 264 | 0x108 | HalPrepareForBugcheck | FUNCTION_PTR* |
| 272 | 0x110 | HalQueryWakeTime | FUNCTION_PTR* |
| 280 | 0x118 | HalReportIdleStateUsage | FUNCTION_PTR* |
| 288 | 0x120 | HalTscSynchronization | FUNCTION_PTR* |
| 296 | 0x128 | HalWheaInitProcessorGenericSection | FUNCTION_PTR* |
| 304 | 0x130 | HalStopLegacyUsbInterrupts | FUNCTION_PTR* |
| 312 | 0x138 | HalReadWheaPhysicalMemory | FUNCTION_PTR* |
| 320 | 0x140 | HalWriteWheaPhysicalMemory | FUNCTION_PTR* |
| 328 | 0x148 | HalDpMaskLevelTriggeredInterrupts | FUNCTION_PTR* |
| 336 | 0x150 | HalDpUnmaskLevelTriggeredInterrupts | FUNCTION_PTR* |
| 344 | 0x158 | HalDpGetInterruptReplayState | FUNCTION_PTR* |
| 352 | 0x160 | HalDpReplayInterrupts | FUNCTION_PTR* |
| 360 | 0x168 | HalQueryIoPortAccessSupported | FUNCTION_PTR* |
| 368 | 0x170 | KdSetupIntegratedDeviceForDebugging | FUNCTION_PTR* |
| 376 | 0x178 | KdReleaseIntegratedDeviceForDebugging | FUNCTION_PTR* |
| 384 | 0x180 | HalGetEnlightenmentInformation | FUNCTION_PTR* |
| 392 | 0x188 | HalAllocateEarlyPages | FUNCTION_PTR* |
| 400 | 0x190 | HalMapEarlyPages | FUNCTION_PTR* |
| 408 | 0x198 | Dummy1 | VOID* |
| 416 | 0x1A0 | Dummy2 | VOID* |
| 424 | 0x1A8 | HalNotifyProcessorFreeze | FUNCTION_PTR* |
| 432 | 0x1B0 | HalPrepareProcessorForIdle | FUNCTION_PTR* |
| 440 | 0x1B8 | HalRegisterLogRoutine | FUNCTION_PTR* |
| 448 | 0x1C0 | HalResumeProcessorFromIdle | FUNCTION_PTR* |
| 456 | 0x1C8 | Dummy | VOID* |
| 464 | 0x1D0 | HalVectorToIDTEntryEx | FUNCTION_PTR* |
| 472 | 0x1D8 | HalSecondaryInterruptQueryPrimaryInformation | FUNCTION_PTR* |
| 480 | 0x1E0 | HalMaskInterrupt | FUNCTION_PTR* |
| 488 | 0x1E8 | HalUnmaskInterrupt | FUNCTION_PTR* |
| 496 | 0x1F0 | HalIsInterruptTypeSecondary | FUNCTION_PTR* |
| 504 | 0x1F8 | HalAllocateGsivForSecondaryInterrupt | FUNCTION_PTR* |
| 512 | 0x200 | HalAddInterruptRemapping | FUNCTION_PTR* |
| 520 | 0x208 | HalRemoveInterruptRemapping | FUNCTION_PTR* |
| 528 | 0x210 | HalSaveAndDisableHvEnlightenment | FUNCTION_PTR* |
| 536 | 0x218 | HalRestoreHvEnlightenment | FUNCTION_PTR* |
| 544 | 0x220 | HalFlushIoBuffersExternalCache | FUNCTION_PTR* |
| 552 | 0x228 | HalFlushExternalCache | FUNCTION_PTR* |
| 560 | 0x230 | HalPciEarlyRestore | FUNCTION_PTR* |
| 568 | 0x238 | HalGetProcessorId | FUNCTION_PTR* |
| 576 | 0x240 | HalAllocatePmcCounterSet | FUNCTION_PTR* |
| 584 | 0x248 | HalCollectPmcCounters | FUNCTION_PTR* |
| 592 | 0x250 | HalFreePmcCounterSet | FUNCTION_PTR* |
| 600 | 0x258 | HalProcessorHalt | FUNCTION_PTR* |
| 608 | 0x260 | HalTimerQueryCycleCounter | FUNCTION_PTR* |
| 616 | 0x268 | Dummy3 | VOID* |
| 624 | 0x270 | HalPciMarkHiberPhase | FUNCTION_PTR* |
| 632 | 0x278 | HalQueryProcessorRestartEntryPoint | FUNCTION_PTR* |
| 640 | 0x280 | HalRequestInterrupt | FUNCTION_PTR* |
| 648 | 0x288 | HalEnumerateUnmaskedInterrupts | FUNCTION_PTR* |
| 656 | 0x290 | HalFlushAndInvalidatePageExternalCache | FUNCTION_PTR* |
| 664 | 0x298 | KdEnumerateDebuggingDevices | FUNCTION_PTR* |
| 672 | 0x2A0 | HalFlushIoRectangleExternalCache | FUNCTION_PTR* |
| 680 | 0x2A8 | HalPowerEarlyRestore | FUNCTION_PTR* |
| 688 | 0x2B0 | HalQueryCapsuleCapabilities | FUNCTION_PTR* |
| 696 | 0x2B8 | HalUpdateCapsule | FUNCTION_PTR* |
| 704 | 0x2C0 | HalPciMultiStageResumeCapable | FUNCTION_PTR* |
| 712 | 0x2C8 | HalDmaFreeCrashDumpRegisters | FUNCTION_PTR* |
| 720 | 0x2D0 | HalAcpiAoacCapable | FUNCTION_PTR* |
| 728 | 0x2D8 | HalInterruptSetDestination | FUNCTION_PTR* |
| 736 | 0x2E0 | HalGetClockConfiguration | FUNCTION_PTR* |
| 744 | 0x2E8 | HalClockTimerActivate | FUNCTION_PTR* |
| 752 | 0x2F0 | HalClockTimerInitialize | FUNCTION_PTR* |
| 760 | 0x2F8 | HalClockTimerStop | FUNCTION_PTR* |
| 768 | 0x300 | HalClockTimerArm | FUNCTION_PTR* |
| 776 | 0x308 | HalTimerOnlyClockInterruptPending | FUNCTION_PTR* |
| 784 | 0x310 | HalAcpiGetMultiNode | FUNCTION_PTR* |
| 792 | 0x318 | HalPowerSetRebootHandler | FUNCTION_PTR* |
| 800 | 0x320 | HalIommuRegisterDispatchTable | FUNCTION_PTR* |
| 808 | 0x328 | HalTimerWatchdogStart | FUNCTION_PTR* |
| 816 | 0x330 | HalTimerWatchdogResetCountdown | FUNCTION_PTR* |
| 824 | 0x338 | HalTimerWatchdogStop | FUNCTION_PTR* |
| 832 | 0x340 | HalTimerWatchdogGeneratedLastReset | FUNCTION_PTR* |
| 840 | 0x348 | HalTimerWatchdogTriggerSystemReset | FUNCTION_PTR* |
| 848 | 0x350 | HalInterruptVectorDataToGsiv | FUNCTION_PTR* |
| 856 | 0x358 | HalInterruptGetHighestPriorityInterrupt | FUNCTION_PTR* |
| 864 | 0x360 | HalProcessorOn | FUNCTION_PTR* |
| 872 | 0x368 | HalProcessorOff | FUNCTION_PTR* |
| 880 | 0x370 | HalProcessorFreeze | FUNCTION_PTR* |
| 888 | 0x378 | HalDmaLinkDeviceObjectByToken | FUNCTION_PTR* |
| 896 | 0x380 | HalDmaCheckAdapterToken | FUNCTION_PTR* |
| 904 | 0x388 | Dummy4 | VOID* |
| 912 | 0x390 | HalTimerConvertPerformanceCounterToAuxiliaryCounter | FUNCTION_PTR* |
| 920 | 0x398 | HalTimerConvertAuxiliaryCounterToPerformanceCounter | FUNCTION_PTR* |
| 928 | 0x3A0 | HalTimerQueryAuxiliaryCounterFrequency | FUNCTION_PTR* |
| 936 | 0x3A8 | HalConnectThermalInterrupt | FUNCTION_PTR* |
| 944 | 0x3B0 | HalIsEFIRuntimeActive | FUNCTION_PTR* |
| 952 | 0x3B8 | HalTimerQueryAndResetRtcErrors | FUNCTION_PTR* |
| 960 | 0x3C0 | HalAcpiLateRestore | FUNCTION_PTR* |
| 968 | 0x3C8 | KdWatchdogDelayExpiration | FUNCTION_PTR* |
| 976 | 0x3D0 | HalGetProcessorStats | FUNCTION_PTR* |
| 984 | 0x3D8 | HalTimerWatchdogQueryDueTime | FUNCTION_PTR* |
| 992 | 0x3E0 | HalConnectSyntheticInterrupt | FUNCTION_PTR* |
| 1000 | 0x3E8 | HalPreprocessNmi | FUNCTION_PTR* |
| 1008 | 0x3F0 | HalEnumerateEnvironmentVariablesWithFilter | FUNCTION_PTR* |
| 1016 | 0x3F8 | HalCaptureLastBranchRecordStack | FUNCTION_PTR* |
| 1024 | 0x400 | HalClearLastBranchRecordStack | FUNCTION_PTR* |
| 1032 | 0x408 | HalConfigureLastBranchRecord | FUNCTION_PTR* |
| 1040 | 0x410 | HalGetLastBranchInformation | FUNCTION_PTR* |
| 1048 | 0x418 | HalResumeLastBranchRecord | FUNCTION_PTR* |
| 1056 | 0x420 | HalStartLastBranchRecord | FUNCTION_PTR* |
| 1064 | 0x428 | HalStopLastBranchRecord | FUNCTION_PTR* |
| 1072 | 0x430 | HalIommuBlockDevice | FUNCTION_PTR* |
| 1080 | 0x438 | HalIommuUnblockDevice | FUNCTION_PTR* |
| 1088 | 0x440 | HalGetIommuInterface | FUNCTION_PTR* |
| 1096 | 0x448 | HalRequestGenericErrorRecovery | FUNCTION_PTR* |
| 1104 | 0x450 | HalTimerQueryHostPerformanceCounter | FUNCTION_PTR* |
| 1112 | 0x458 | HalTopologyQueryProcessorRelationships | FUNCTION_PTR* |
| 1120 | 0x460 | HalInitPlatformDebugTriggers | FUNCTION_PTR* |
| 1128 | 0x468 | HalRunPlatformDebugTriggers | FUNCTION_PTR* |
| 1136 | 0x470 | HalTimerGetReferencePage | FUNCTION_PTR* |
| 1144 | 0x478 | HalGetHiddenProcessorPowerInterface | FUNCTION_PTR* |
| 1152 | 0x480 | HalGetHiddenProcessorPackageId | FUNCTION_PTR* |
| 1160 | 0x488 | HalGetHiddenPackageProcessorCount | FUNCTION_PTR* |
| 1168 | 0x490 | HalGetHiddenProcessorApicIdByIndex | FUNCTION_PTR* |
| 1176 | 0x498 | HalRegisterHiddenProcessorIdleState | FUNCTION_PTR* |
| 1184 | 0x4A0 | HalIommuReportIommuFault | FUNCTION_PTR* |
| 1192 | 0x4A8 | HalIommuDmaRemappingCapable | FUNCTION_PTR* |
| 1200 | 0x4B0 | HalAllocatePmcCounterSetEx | FUNCTION_PTR* |
| 1208 | 0x4B8 | HalStartProfileInterruptEx | FUNCTION_PTR* |
| 1216 | 0x4C0 | HalGetIommuInterfaceEx | FUNCTION_PTR* |
| 1224 | 0x4C8 | HalNotifyIommuDomainPolicyChange | FUNCTION_PTR* |
| 1232 | 0x4D0 | HalPciGetDeviceLocationFromPhysicalAddress | FUNCTION_PTR* |
| 1240 | 0x4D8 | HalInvokeSmc | FUNCTION_PTR* |
| 1248 | 0x4E0 | HalInvokeHvc | FUNCTION_PTR* |
| 1256 | 0x4E8 | HalGetSoftRebootDatabase | FUNCTION_PTR* |
| 1264 | 0x4F0 | HalRequestPmuAccess | FUNCTION_PTR* |
| 1272 | 0x4F8 | HalTopologyQueryProcessorCacheInformation | FUNCTION_PTR* |
| 1280 | 0x500 | HalReleasePmuAccessRequest | FUNCTION_PTR* |
| 1288 | 0x508 | HalTimerQueryRtcErrors | FUNCTION_PTR* |
| 1296 | 0x510 | HalExternalPciConfigSpaceAccess | FUNCTION_PTR* |
