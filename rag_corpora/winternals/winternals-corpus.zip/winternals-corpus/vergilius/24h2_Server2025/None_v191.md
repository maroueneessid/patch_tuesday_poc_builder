---
name: None
kind: ARRAY
sizeof: 896
sizeof_hex: 0x380
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# None

**Kind:** ARRAY | **Size:** 896 bytes (0x380)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 32 | 0x020 | element | _WHEA_XPF_MC_BANK_DESCRIPTOR |
