---
name: None
kind: ARRAY
sizeof: 10
sizeof_hex: 0xA
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# None

**Kind:** ARRAY | **Size:** 10 bytes (0xA)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 10 | 0x00A | element | CHAR |
