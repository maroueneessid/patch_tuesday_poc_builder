---
name: IORING_BUFFER_INFO
kind: STRUCT
sizeof: 16
sizeof_hex: 0x10
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# IORING_BUFFER_INFO

**Kind:** STRUCT | **Size:** 16 bytes (0x10)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | Address | VOID* |
| 8 | 0x008 | Length | ULONG |
