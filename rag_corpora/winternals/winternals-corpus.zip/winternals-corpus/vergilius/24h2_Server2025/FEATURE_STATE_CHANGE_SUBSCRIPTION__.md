---
name: FEATURE_STATE_CHANGE_SUBSCRIPTION__
kind: STRUCT
sizeof: 4
sizeof_hex: 0x4
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# FEATURE_STATE_CHANGE_SUBSCRIPTION__

**Kind:** STRUCT | **Size:** 4 bytes (0x4)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | unused | LONG |
