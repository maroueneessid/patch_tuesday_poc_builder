---
name: ETW_COMPRESSION_RESUMPTION_MODE
kind: ENUM
sizeof: 4
sizeof_hex: 0x4
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# ETW_COMPRESSION_RESUMPTION_MODE

**Kind:** ENUM | **Size:** 4 bytes (0x4)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | EtwCompressionModeRestart | LONG |
| 1 | 0x001 | EtwCompressionModeNoDisable | LONG |
| 2 | 0x002 | EtwCompressionModeNoRestart | LONG |
