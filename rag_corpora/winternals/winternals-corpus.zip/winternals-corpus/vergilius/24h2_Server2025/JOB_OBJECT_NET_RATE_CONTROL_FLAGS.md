---
name: JOB_OBJECT_NET_RATE_CONTROL_FLAGS
kind: ENUM
sizeof: 4
sizeof_hex: 0x4
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# JOB_OBJECT_NET_RATE_CONTROL_FLAGS

**Kind:** ENUM | **Size:** 4 bytes (0x4)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 1 | 0x001 | JOB_OBJECT_NET_RATE_CONTROL_ENABLE | LONG |
| 2 | 0x002 | JOB_OBJECT_NET_RATE_CONTROL_MAX_BANDWIDTH | LONG |
| 4 | 0x004 | JOB_OBJECT_NET_RATE_CONTROL_DSCP_TAG | LONG |
| 7 | 0x007 | JOB_OBJECT_NET_RATE_CONTROL_VALID_FLAGS | LONG |
