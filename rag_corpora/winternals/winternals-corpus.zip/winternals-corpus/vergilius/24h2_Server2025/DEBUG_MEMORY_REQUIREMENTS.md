---
name: DEBUG_MEMORY_REQUIREMENTS
kind: STRUCT
sizeof: 32
sizeof_hex: 0x20
os: Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1)
build: 10.0.26100.1742
arch: x64
source: vergilius
---

# DEBUG_MEMORY_REQUIREMENTS

**Kind:** STRUCT | **Size:** 32 bytes (0x20)
**OS:** Windows 11 24H2 | Server 2025 (2024 Update, Germanium R1) | **Build:** 10.0.26100.1742 | **Arch:** x64

## Fields

| Offset | Offset (hex) | Name | Type |
|--------|-------------|------|------|
| 0 | 0x000 | Start | _LARGE_INTEGER |
| 8 | 0x008 | MaxEnd | _LARGE_INTEGER |
| 16 | 0x010 | VirtualAddress | VOID* |
| 24 | 0x018 | Length | ULONG |
| 28 | 0x01C | Cached | UCHAR |
| 29 | 0x01D | Aligned | UCHAR |
